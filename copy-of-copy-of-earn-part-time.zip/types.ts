
export interface Transaction {
  id: string;
  date: string;
  description: string;
  type: 'earned' | 'redeemed' | 'penalty';
  coins: number;
  amountUSD?: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  profilePictureUrl: string;
  coins: number;
  tasksCompleted: number;
  referralCode: string;
  completedTaskIds: string[];
  transactions: Transaction[];
  isAdmin?: boolean;
  location?: string;
  phoneNumber?: string;
  joinDate?: string;
}

export enum AdUnitType {
  BANNER = 'BANNER',
  INTERSTITIAL = 'INTERSTITIAL',
  REWARDED = 'REWARDED',
}

export enum AdProvider {
  ADSENSE = 'Google AdSense',
  ADMOB = 'Google AdMob',
  UNITY = 'Unity Ads',
  APPLOVIN = 'AppLovin',
}

export interface AdUnit {
  id: string;
  name: string;
  type: AdUnitType;
  provider: AdProvider;
  enabled: boolean;
  revenueGenerated: number; // Tracks estimated revenue for admin
}

export interface AdSettings {
  adsEnabled: boolean;
  adSensePublisherId: string | null;
  adMobAppId: string | null;
  unityGameId: string | null;
  adUnits: AdUnit[];
}

export interface FinancialSettings {
  conversionRate: number; // How many coins = 1 USD
  minWithdrawalThreshold: number; // Minimum coins to withdraw
  currency: string;
}

export interface AppDatabase {
  users: User[];
  tasks: Task[];
  categories: Category[];
  adSettings: AdSettings;
  financialSettings: FinancialSettings;
  logs: { timestamp: number; message: string; type: 'info' | 'success' | 'error' }[];
}

export enum Screen {
  Home = 'HOME',
  Tasks = 'TASKS',
  TaskDetail = 'TASK_DETAIL',
  Wallet = 'WALLET',
  Profile = 'PROFILE',
  CreateTask = 'CREATE_TASK',
  Admin = 'ADMIN',
  EditTask = 'EDIT_TASK',
  Security = 'SECURITY',
  HelpAndSupport = 'HELP_AND_SUPPORT',
  ForgotPassword = 'FORGOT_PASSWORD',
  AdminTask = 'ADMIN_TASK',
  AdminUserList = 'ADMIN_USER_LIST',
  AdminUserDetails = 'ADMIN_USER_DETAILS',
  AdminCategoryList = 'ADMIN_CATEGORY_LIST',
  AdminEditCategory = 'ADMIN_EDIT_CATEGORY',
  AdminAdRevenue = 'ADMIN_AD_REVENUE',
  AdminFinancials = 'ADMIN_FINANCIALS',
}

export enum TaskType {
  SURVEY = 'SURVEY',
  CREATIVE = 'CREATIVE',
  DATA_ENTRY = 'DATA_ENTRY',
  APP_INSTALLATION = 'APP_INSTALLATION',
  GENERIC = 'GENERIC',
  REWARDED_AD = 'REWARDED_AD',
  CAPTCHA = 'CAPTCHA',
  YES_NO_QUIZ = 'YES_NO_QUIZ',
  GRADED_QUIZ = 'GRADED_QUIZ',
}

export interface Task {
  id: string;
  categoryId: string;
  title: string;
  description: string;
  coins: number;
  timeEstimateMinutes: number;
  verificationMethod: string;
  type: TaskType;
  questions?: string[];
  videoUrl?: string;
  appInstallationUrl?: string;
  captchaImageUrl?: string;
  captchaCorrectAnswer?: string;
  captchaImageGrid?: string[];
  captchaGridCorrectIndices?: number[];
  yesNoQuestion?: string;
  correctYesNoAnswer?: 'Yes' | 'No';
  quizQuestions?: { questionText: string; correctAnswer: 'Yes' | 'No' }[];
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  taskCount: number;
  lastGeneratedAt?: number;
}

export interface RedemptionTier {
  name: 'Small' | 'Medium' | 'Large';
  coins: number;
  usd: number;
  bonusText?: string;
}

export type PaymentMethod = 'PayPal' | 'Google Pay' | 'Paytm' | 'Bank Transfer' | 'Amazon Gift Card' | 'Mobile Recharge' | 'Donate to Charity' | 'Apple Pay' | 'Venmo' | 'Cash App' | 'Starbucks Gift Card';
