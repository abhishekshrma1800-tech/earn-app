import React from 'react';
import Icon from './icons';

interface AppVerificationModalProps {
  isOpen: boolean;
  onVerified: () => void;
}

const VerificationStatus: React.FC<{ text: string, done: boolean }> = ({ text, done }) => (
    <div className="flex items-center space-x-3">
        {done ? (
            <Icon name="CheckCircle" className="w-6 h-6 text-success" />
        ) : (
            <div className="w-6 h-6 flex items-center justify-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary"></div>
            </div>
        )}
        <span className={`text-lg ${done ? 'text-on-surface' : 'text-on-surface-secondary'}`}>{text}</span>
    </div>
);

const AppVerificationModal: React.FC<AppVerificationModalProps> = ({ isOpen, onVerified }) => {
    const [status, setStatus] = React.useState(0); // 0: initial, 1: checking, 2: confirmed

    React.useEffect(() => {
        if (isOpen) {
            setStatus(0); // Reset on open
            const timer1 = setTimeout(() => setStatus(1), 1500);
            const timer2 = setTimeout(() => setStatus(2), 3500);
            const timer3 = setTimeout(() => onVerified(), 4500);

            return () => {
                clearTimeout(timer1);
                clearTimeout(timer2);
                clearTimeout(timer3);
            };
        }
    }, [isOpen, onVerified]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex flex-col items-center justify-center p-4 text-white" aria-modal="true" role="dialog">
            <div className="bg-surface rounded-lg shadow-xl p-8 w-full max-w-sm text-center">
                <h2 className="text-2xl font-bold text-on-surface mb-6">Verifying Installation...</h2>
                <div className="space-y-4 text-left">
                    <VerificationStatus text="Connecting to service..." done={status >= 1} />
                    <VerificationStatus text="Checking installation..." done={status >= 2} />
                    <VerificationStatus text="Verification complete!" done={status >= 2} />
                </div>
                 <p className="text-sm text-on-surface-secondary mt-6">Please keep the app open. This may take a few moments.</p>
            </div>
        </div>
    );
};

export default AppVerificationModal;
