import React from 'react';
import { User, Screen } from '../types';
import Icon from './icons';

interface HeaderProps {
  user: User;
  onProfileClick: () => void;
  activeScreen: Screen;
  onBack: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onProfileClick, activeScreen, onBack }) => {
  const rootScreens = [Screen.Home, Screen.Wallet, Screen.Profile, Screen.Admin];
  const showBackButton = !rootScreens.includes(activeScreen);

  return (
    <header className="bg-primary text-on-primary p-4 flex justify-between items-center shadow-md sticky top-0 z-10">
      <div className="flex items-center space-x-2">
        {showBackButton && (
          <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-black/20 focus:outline-none focus:ring-2 focus:ring-white">
            <Icon name="ArrowLeft" className="w-6 h-6" />
          </button>
        )}
        <h1 className="text-xl font-bold">Earn Part-Time</h1>
      </div>
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2 bg-black bg-opacity-20 px-3 py-1 rounded-full">
          <Icon name="Coin" className="w-5 h-5 text-yellow-300" />
          <span className="font-semibold">{user.coins.toLocaleString()}</span>
        </div>
        <button onClick={onProfileClick} className="focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-primary focus:ring-white rounded-full">
          <img
            src={user.profilePictureUrl}
            alt="Profile"
            className="w-10 h-10 rounded-full border-2 border-on-primary"
          />
        </button>
      </div>
    </header>
  );
};

export default Header;
