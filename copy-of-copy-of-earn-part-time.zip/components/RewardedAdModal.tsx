import React, { useState, useEffect } from 'react';
import { Task } from '../types';
import AdSensePlaceholder, { placeholderAds } from './AdSensePlaceholder';
import Icon from './icons';

interface RewardedAdModalProps {
    task: Task;
    onClose: () => void;
    onComplete: () => void;
}

const REWARD_AD_DURATION = 15; // seconds
const AD_CYCLE_INTERVAL = 3000; // milliseconds

const RewardedAdModal: React.FC<RewardedAdModalProps> = ({ task, onClose, onComplete }) => {
    const [countdown, setCountdown] = useState(REWARD_AD_DURATION);
    const [adIndex, setAdIndex] = useState(0);
    const [isComplete, setIsComplete] = useState(false);
    
    useEffect(() => {
        if (isComplete) return;

        if (countdown <= 0) {
            setIsComplete(true);
            setTimeout(() => {
                onComplete();
            }, 1500); // Wait a bit after showing the "rewarded" message
            return;
        }

        const countdownTimer = setInterval(() => {
            setCountdown(prev => prev - 1);
        }, 1000);

        const adCycleTimer = setInterval(() => {
            setAdIndex(prevIndex => (prevIndex + 1) % placeholderAds.length);
        }, AD_CYCLE_INTERVAL);


        return () => {
            clearInterval(countdownTimer);
            clearInterval(adCycleTimer);
        };
    }, [countdown, onComplete, isComplete]);
    
    const progress = ((REWARD_AD_DURATION - countdown) / REWARD_AD_DURATION) * 100;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex flex-col items-center justify-between p-4 text-white">
            <header className="w-full flex justify-between items-center">
                <h2 className="text-xl font-bold">Sponsored Content</h2>
                <button 
                    onClick={onClose} 
                    disabled={countdown > 5} 
                    className="p-2 rounded-full transition-opacity disabled:opacity-50 enabled:hover:bg-white/20"
                    aria-label="Close ad"
                >
                    <Icon name="X" className="w-7 h-7" />
                </button>
            </header>
            
            <div className="w-full max-w-sm flex-grow flex items-center justify-center">
                 {isComplete ? (
                    <div className="text-center">
                        <Icon name="CheckCircle" className="w-16 h-16 text-success mx-auto mb-4" />
                        <h3 className="text-3xl font-bold">Reward Granted!</h3>
                        <p className="text-xl text-yellow-300 font-semibold mt-2">+{task.coins} Coins</p>
                    </div>
                ) : (
                    <AdSensePlaceholder ad={placeholderAds[adIndex]} />
                )}
            </div>

            <footer className="w-full max-w-sm text-center">
                {!isComplete && (
                    <>
                        <p className="mb-2">You will be rewarded in {countdown} seconds...</p>
                        <div className="w-full bg-white/20 rounded-full h-2.5">
                            <div 
                                className="bg-primary h-2.5 rounded-full transition-all duration-1000 linear" 
                                style={{width: `${progress}%`}}
                            ></div>
                        </div>
                    </>
                )}
            </footer>
        </div>
    );
};

export default RewardedAdModal;