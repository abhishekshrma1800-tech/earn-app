import React, { useState, useEffect, useRef } from 'react';
import Icon from '../icons';

interface AdminOtpScreenProps {
    email: string;
    onVerifySuccess: () => void;
    onBackToLogin: () => void;
    simulatedOtp: string;
    onResendOtp: () => Promise<boolean>;
}

const OTP_LENGTH = 6;
const RESEND_COOLDOWN_SECONDS = 30;

const AdminOtpScreen: React.FC<AdminOtpScreenProps> = ({ email, onVerifySuccess, onBackToLogin, simulatedOtp, onResendOtp }) => {
    const [otp, setOtp] = useState<string[]>(new Array(OTP_LENGTH).fill(''));
    const [error, setError] = useState('');
    const [isVerifying, setIsVerifying] = useState(false);
    const [resendCooldown, setResendCooldown] = useState(RESEND_COOLDOWN_SECONDS);
    const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

    useEffect(() => {
        // Focus the first input on mount
        inputRefs.current[0]?.focus();
    }, []);

    useEffect(() => {
        // Cooldown timer logic
        if (resendCooldown > 0) {
            const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
            return () => clearTimeout(timer);
        }
    }, [resendCooldown]);
    
    const handleOtpChange = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
        const value = e.target.value;
        if (/[^0-9]/.test(value)) return;

        const newOtp = [...otp];
        newOtp[index] = value.slice(-1);
        setOtp(newOtp);

        if (value && index < OTP_LENGTH - 1) {
            inputRefs.current[index + 1]?.focus();
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
        if (e.key === 'Backspace' && !otp[index] && index > 0) {
            inputRefs.current[index - 1]?.focus();
        }
    };

    const handlePaste = (e: React.ClipboardEvent<HTMLDivElement>) => {
        e.preventDefault();
        const pastedData = e.clipboardData.getData('text').trim();
        if (pastedData.length === OTP_LENGTH && /^[0-9]+$/.test(pastedData)) {
            const newOtp = pastedData.split('');
            setOtp(newOtp);
            inputRefs.current[OTP_LENGTH - 1]?.focus();
        }
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        const enteredOtp = otp.join('');
        
        if (enteredOtp.length !== OTP_LENGTH) {
            setError('Please enter a 6-digit OTP.');
            return;
        }

        setIsVerifying(true);
        
        setTimeout(() => {
            if (enteredOtp === simulatedOtp) {
                onVerifySuccess();
            } else {
                setError('Invalid OTP. Please try again.');
                setIsVerifying(false);
                setOtp(new Array(OTP_LENGTH).fill(''));
                inputRefs.current[0]?.focus();
            }
        }, 1000);
    };

    const handleResend = async () => {
        if (resendCooldown === 0) {
            const success = await onResendOtp();
            if (success) {
                setResendCooldown(RESEND_COOLDOWN_SECONDS);
                setOtp(new Array(OTP_LENGTH).fill(''));
                setError('');
                inputRefs.current[0]?.focus();
            }
        }
    };

    return (
        <div className="min-h-screen bg-background flex flex-col justify-center items-center p-4">
            <div className="max-w-md w-full mx-auto bg-surface p-8 rounded-2xl shadow-xl text-center">
                <Icon name="Admin" className="w-20 h-20 text-primary mx-auto mb-6" />
                <h1 className="text-3xl font-bold text-on-surface">Admin Verification</h1>
                <p className="text-on-surface-secondary mt-4">
                    For security, we've sent a one-time password (OTP) to <span className="font-bold text-primary">{email}</span>.
                </p>
                
                <div className="mt-4 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 p-3 rounded-md text-left" role="alert">
                    <p className="font-bold">For Demo Purposes</p>
                    <p>The One-Time Password is: <span className="font-mono font-semibold">{simulatedOtp}</span></p>
                </div>

                <form onSubmit={handleSubmit} className="mt-8 space-y-6">
                    <div>
                        <label htmlFor="otp-0" className="sr-only">Enter OTP</label>
                        <div className="flex justify-center space-x-2 md:space-x-4" onPaste={handlePaste}>
                            {otp.map((digit, index) => (
                                <input
                                    key={index}
                                    ref={(el) => (inputRefs.current[index] = el)}
                                    id={`otp-${index}`}
                                    name={`otp-${index}`}
                                    type="tel"
                                    autoComplete="one-time-code"
                                    required
                                    value={digit}
                                    onChange={(e) => handleOtpChange(e, index)}
                                    onKeyDown={(e) => handleKeyDown(e, index)}
                                    onFocus={(e) => e.target.select()}
                                    className="w-12 h-14 md:w-14 md:h-16 text-center text-2xl md:text-3xl font-semibold border-2 border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition"
                                    maxLength={1}
                                />
                            ))}
                        </div>
                    </div>
                    
                    {error && <p className="text-sm text-error text-center">{error}</p>}

                    <div>
                        <button
                            type="submit"
                            disabled={isVerifying}
                            className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-on-primary bg-primary hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition disabled:bg-gray-400"
                        >
                             {isVerifying && (
                                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                            )}
                            {isVerifying ? 'Verifying...' : 'Verify'}
                        </button>
                    </div>
                </form>

                <div className="mt-6 text-center text-sm">
                    <button
                        onClick={handleResend}
                        disabled={resendCooldown > 0}
                        className="font-medium text-primary hover:text-primary-focus focus:outline-none disabled:text-on-surface-secondary disabled:cursor-not-allowed"
                    >
                        {resendCooldown > 0 ? `Resend OTP in ${resendCooldown}s` : "Didn't receive code? Resend"}
                    </button>
                </div>
                <div className="mt-2 text-center text-sm">
                    <button onClick={onBackToLogin} className="font-medium text-primary hover:text-primary-focus focus:outline-none">
                        Back to Log In
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AdminOtpScreen;
