import React, { useState, useEffect } from 'react';
import { Category, Task, TaskType } from '../../types';
import Icon from '../icons';
import { calculateCoins } from '../../constants';

interface CreateTaskScreenProps {
  categories: Category[];
  onAddTask: (task: Omit<Task, 'id'>) => void;
}

const CreateTaskScreen: React.FC<CreateTaskScreenProps> = ({ categories, onAddTask }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [timeEstimate, setTimeEstimate] = useState(5);
  const [coins, setCoins] = useState(calculateCoins(5));
  const [categoryId, setCategoryId] = useState(categories[0]?.id || '');
  const [videoUrl, setVideoUrl] = useState('');
  const [appInstallationUrl, setAppInstallationUrl] = useState('');
  const [questions, setQuestions] = useState<string[]>([]);
  const [error, setError] = useState('');

  const selectedCategoryName = categories.find(c => c.id === categoryId)?.name;
  const isSurveyCategory = selectedCategoryName === 'Survey Tasks';
  const isVideoCategory = selectedCategoryName === 'Video Watching';
  const isAppInstallCategory = selectedCategoryName === 'App Installation';
  const isWatchAndEarnCategory = selectedCategoryName === 'Watch & Earn';

  useEffect(() => {
    setCoins(calculateCoins(Number(timeEstimate)));
  }, [timeEstimate]);

  useEffect(() => {
    if (isSurveyCategory) {
      if (questions.length === 0) {
        setQuestions(['']); // Initialize with one empty question
      }
    } else {
      setQuestions([]); // Clear questions if not a survey
    }
  }, [isSurveyCategory]);
  
  useEffect(() => {
    // Clear irrelevant data when category changes
    if (!isVideoCategory) setVideoUrl('');
    if (!isAppInstallCategory) setAppInstallationUrl('');
  }, [categoryId, isVideoCategory, isAppInstallCategory]);

  const handleQuestionChange = (index: number, value: string) => {
    const newQuestions = [...questions];
    newQuestions[index] = value;
    setQuestions(newQuestions);
  };

  const addQuestionField = () => {
    if (questions.length < 10) {
      setQuestions([...questions, '']);
    }
  };

  const removeQuestionField = (index: number) => {
    if (questions.length > 1) {
      const newQuestions = questions.filter((_, i) => i !== index);
      setQuestions(newQuestions);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!title.trim() || !description.trim() || !categoryId) {
      setError('Please fill out title, description, and category.');
      return;
    }
    
    if (Number(timeEstimate) <= 0) {
      setError('Time Estimate must be a positive number.');
      return;
    }

    const finalQuestions = questions.map(q => q.trim()).filter(q => q);
    if (isSurveyCategory && finalQuestions.length === 0) {
      setError('Please add at least one question for the survey.');
      return;
    }

    if (isAppInstallCategory && !appInstallationUrl.trim()) {
        setError('Please provide an app installation URL.');
        return;
    }

    let taskType: TaskType;
    if (isWatchAndEarnCategory) {
      taskType = TaskType.REWARDED_AD;
    } else {
      switch (selectedCategoryName) {
        case 'Survey Tasks': taskType = TaskType.SURVEY; break;
        case 'Creative Tasks': taskType = TaskType.CREATIVE; break;
        case 'Data Collection': taskType = TaskType.DATA_ENTRY; break;
        case 'App Installation': taskType = TaskType.APP_INSTALLATION; break;
        default: taskType = TaskType.GENERIC;
      }
    }

    const newTask: Omit<Task, 'id'> = {
      title,
      description,
      coins: Number(coins),
      timeEstimateMinutes: Number(timeEstimate),
      categoryId,
      verificationMethod: 'Automatic', // Default for now
      type: taskType,
      ...(videoUrl && isVideoCategory && { videoUrl }),
      ...(appInstallationUrl && isAppInstallCategory && { appInstallationUrl }),
      ...(taskType === TaskType.SURVEY && { questions: finalQuestions })
    };
    
    onAddTask(newTask);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-on-surface">Create New Task</h2>
      </div>
      
      <form onSubmit={handleSubmit} className="bg-surface p-6 rounded-lg shadow space-y-4">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-on-surface-secondary mb-1">Task Title</label>
          <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} required className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" />
        </div>
        
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-on-surface-secondary mb-1">Description</label>
          <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} required rows={4} className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition"></textarea>
        </div>

        <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="timeEstimate" className="block text-sm font-medium text-on-surface-secondary mb-1">Time (Minutes)</label>
              <input type="number" id="timeEstimate" value={timeEstimate} onChange={e => setTimeEstimate(Number(e.target.value))} required min="1" className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" />
            </div>
            <div>
              <label htmlFor="coins" className="block text-sm font-medium text-on-surface-secondary mb-1">Coins Reward</label>
                <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Icon name="Coin" className="w-5 h-5 text-yellow-500" />
                    </div>
                    <input type="number" id="coins" value={coins} readOnly className="w-full p-2 pl-10 border rounded-md bg-gray-100 text-gray-700 transition" />
                </div>
            </div>
        </div>

        <div>
          <label htmlFor="category" className="block text-sm font-medium text-on-surface-secondary mb-1">Category</label>
          <select id="category" value={categoryId} onChange={e => setCategoryId(e.target.value)} required className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition bg-surface text-black">
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>
        </div>
        
        {isSurveyCategory && (
          <div className="border-t pt-4">
            <label className="block text-sm font-medium text-on-surface-secondary mb-2">Survey Questions (up to 10)</label>
            <div className="space-y-2">
              {questions.map((q, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <input
                    type="text"
                    placeholder={`Question ${index + 1}`}
                    value={q}
                    onChange={(e) => handleQuestionChange(index, e.target.value)}
                    className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition"
                  />
                  {questions.length > 1 && (
                    <button type="button" onClick={() => removeQuestionField(index)} className="p-2 text-error hover:bg-red-100 rounded-full flex-shrink-0">
                      <Icon name="Trash" className="w-5 h-5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
            {questions.length < 10 && (
              <button type="button" onClick={addQuestionField} className="mt-2 text-primary font-semibold text-sm flex items-center space-x-1 hover:underline">
                <Icon name="Plus" className="w-4 h-4" />
                <span>Add Question</span>
              </button>
            )}
          </div>
        )}

        {isVideoCategory && (
            <div>
                <label htmlFor="videoUrl" className="block text-sm font-medium text-on-surface-secondary mb-1">Video URL (Optional)</label>
                <input type="url" id="videoUrl" value={videoUrl} onChange={e => setVideoUrl(e.target.value)} placeholder="e.g., https://www.youtube.com/watch?v=..." className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" />
            </div>
        )}

        {isAppInstallCategory && (
            <div>
                <label htmlFor="appInstallationUrl" className="block text-sm font-medium text-on-surface-secondary mb-1">App Installation URL</label>
                <input type="url" id="appInstallationUrl" value={appInstallationUrl} onChange={e => setAppInstallationUrl(e.target.value)} placeholder="e.g., https://play.google.com/store/apps/..." required className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" />
            </div>
        )}

        {error && <p className="text-sm text-error text-center">{error}</p>}

        <div className="pt-2">
            <button type="submit" className="w-full bg-primary text-on-primary font-bold py-3 px-4 rounded-lg hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition text-lg">
                Add Task
            </button>
        </div>
      </form>
    </div>
  );
};

export default CreateTaskScreen;