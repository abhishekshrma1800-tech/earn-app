
import React, { useState } from 'react';
import { User, Transaction, RedemptionTier, PaymentMethod, FinancialSettings } from '../../types';
import Icon from '../icons';
import { db } from '../../services/storageService';

const paymentMethods: { name: PaymentMethod; icon: string }[] = [
    { name: 'PayPal', icon: 'Mail' },
    { name: 'Google Pay', icon: 'Google' },
    { name: 'Apple Pay', icon: 'ApplePay' },
    { name: 'Venmo', icon: 'Venmo' },
    { name: 'Cash App', icon: 'Cash' },
    { name: 'Paytm', icon: 'Paytm' },
    { name: 'Bank Transfer', icon: 'Bank' },
    { name: 'Amazon Gift Card', icon: 'Gift' },
    { name: 'Starbucks Gift Card', icon: 'Starbucks' },
    { name: 'Mobile Recharge', icon: 'Mobile' },
    { name: 'Donate to Charity', icon: 'Donate' }
];

interface RedemptionModalProps {
    user: User;
    tier: RedemptionTier;
    onClose: () => void;
    onConfirm: (tier: RedemptionTier, method: PaymentMethod, details: string) => void;
}

const RedemptionModal: React.FC<RedemptionModalProps> = ({ user, tier, onClose, onConfirm }) => {
    const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('PayPal');
    const [paymentDetails, setPaymentDetails] = useState(user.email);
    const [error, setError] = useState('');

    const handleConfirm = () => {
        if (!paymentDetails.trim()) {
            setError('Please enter your payment details.');
            return;
        }
        onConfirm(tier, paymentMethod, paymentDetails);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
            <div className="bg-surface rounded-lg shadow-xl p-6 w-full max-w-md">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold text-on-surface">Confirm Withdrawal</h3>
                    <button onClick={onClose} className="text-on-surface-secondary">
                        <Icon name="X" className="w-6 h-6" />
                    </button>
                </div>
                <div className="space-y-4">
                    <div className="bg-gray-100 p-4 rounded-lg text-center">
                        <p className="text-on-surface-secondary">You are withdrawing</p>
                        <p className="text-3xl font-bold text-primary">{tier.coins.toLocaleString()} Coins</p>
                        <p className="text-lg font-semibold text-on-surface">Value: ${tier.usd.toFixed(2)}</p>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-on-surface-secondary mb-2">Select Method</label>
                        <div className="grid grid-cols-4 gap-2">
                            {paymentMethods.map(({ name, icon }) => (
                                <button
                                    key={name}
                                    onClick={() => setPaymentMethod(name)}
                                    className={`p-2 border rounded-md text-xs font-semibold flex flex-col items-center justify-center space-y-1 h-16 ${paymentMethod === name ? 'bg-primary text-white' : 'bg-surface text-on-surface-secondary'}`}
                                >
                                    <Icon name={icon} className="w-5 h-5" />
                                    <span className="truncate w-full text-center">{name}</span>
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <input
                            type="text"
                            value={paymentDetails}
                            onChange={(e) => setPaymentDetails(e.target.value)}
                            placeholder="Enter payment ID / Email"
                            className="w-full p-2 border rounded-md text-black"
                        />
                         {error && <p className="text-error text-xs mt-1">{error}</p>}
                    </div>
                </div>
                <button onClick={handleConfirm} className="w-full mt-6 py-3 bg-primary text-white rounded-lg font-bold">
                    Confirm & Withdraw
                </button>
            </div>
        </div>
    );
};

const WalletScreen: React.FC<{ user: User; onUpdateUser: (u: Partial<User>) => void }> = ({ user, onUpdateUser }) => {
    const [selectedTier, setSelectedTier] = useState<RedemptionTier | null>(null);
    const financialSettings = db.getFinancialSettings();
    
    const userUsdValue = user.coins / financialSettings.conversionRate;
    const progressToWithdrawal = Math.min((user.coins / financialSettings.minWithdrawalThreshold) * 100, 100);
    const canWithdraw = user.coins >= financialSettings.minWithdrawalThreshold;

    const dynamicTiers: RedemptionTier[] = [
        { name: 'Small', coins: financialSettings.minWithdrawalThreshold, usd: financialSettings.minWithdrawalThreshold / financialSettings.conversionRate },
        { name: 'Medium', coins: financialSettings.minWithdrawalThreshold * 2, usd: (financialSettings.minWithdrawalThreshold * 2 / financialSettings.conversionRate) + 1, bonusText: '+$1 Bonus' },
        { name: 'Large', coins: financialSettings.minWithdrawalThreshold * 4, usd: (financialSettings.minWithdrawalThreshold * 4 / financialSettings.conversionRate) + 5, bonusText: '+$5 Bonus' },
    ];

    const handleRedemption = (tier: RedemptionTier, method: PaymentMethod, details: string) => {
        const newTransaction: Transaction = {
            id: `tx${Date.now()}`,
            date: new Date().toLocaleDateString(),
            description: `Withdrawal via ${method}`,
            type: 'redeemed',
            coins: -tier.coins,
            amountUSD: tier.usd
        };
        onUpdateUser({
            coins: user.coins - tier.coins,
            transactions: [newTransaction, ...(user.transactions || [])]
        });
        setSelectedTier(null);
        db.addLog(`User ${user.name} withdrew $${tier.usd} via ${method}`, 'success');
    };

    return (
        <div className="space-y-6 pb-20">
            <div>
                <h2 className="text-2xl font-bold text-on-surface">My Wallet</h2>
                <p className="text-on-surface-secondary">Balance & Point Conversion</p>
            </div>

            <div className="bg-primary text-on-primary p-6 rounded-xl shadow-lg relative overflow-hidden">
                <div className="relative z-10">
                    <p className="text-sm opacity-80">Current Value</p>
                    <p className="text-5xl font-bold">${userUsdValue.toFixed(2)}</p>
                    <div className="flex items-center space-x-2 mt-2">
                        <Icon name="Coin" className="w-5 h-5 text-yellow-300" />
                        <span className="font-semibold">{user.coins.toLocaleString()} Coins</span>
                    </div>
                </div>
                <Icon name="Wallet" className="absolute -bottom-4 -right-4 w-32 h-32 opacity-10" />
            </div>

            <div className="bg-surface p-4 rounded-lg shadow">
                <div className="flex justify-between items-center mb-2">
                    <h3 className="font-bold text-on-surface">Withdrawal Progress</h3>
                    <span className="text-xs font-bold text-primary">{Math.floor(progressToWithdrawal)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                    <div className="bg-primary h-3 rounded-full transition-all" style={{ width: `${progressToWithdrawal}%` }}></div>
                </div>
                {!canWithdraw && (
                    <p className="text-[10px] text-on-surface-secondary mt-2 flex items-center">
                        <Icon name="Lock" className="w-3 h-3 mr-1" />
                        Minimum {financialSettings.minWithdrawalThreshold.toLocaleString()} coins required to unlock withdrawals.
                    </p>
                )}
            </div>

            <div className="space-y-3">
                <h3 className="font-bold text-on-surface">Choose Redemption Tier</h3>
                {dynamicTiers.map(tier => (
                    <button
                        key={tier.name}
                        onClick={() => canWithdraw && user.coins >= tier.coins && setSelectedTier(tier)}
                        disabled={!canWithdraw || user.coins < tier.coins}
                        className={`w-full p-4 rounded-xl border-2 transition-all text-left flex justify-between items-center ${
                            user.coins >= tier.coins ? 'border-primary bg-white shadow-md' : 'border-gray-200 bg-gray-50 opacity-60'
                        }`}
                    >
                        <div>
                            <div className="flex items-center space-x-2">
                                <span className="font-bold text-lg">{tier.name}</span>
                                {tier.bonusText && <span className="text-[10px] bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-bold">{tier.bonusText}</span>}
                            </div>
                            <p className="text-sm text-on-surface-secondary">{tier.coins.toLocaleString()} Coins</p>
                        </div>
                        <div className="text-right">
                            <p className="text-2xl font-bold text-primary">${tier.usd.toFixed(0)}</p>
                            <p className="text-[10px] uppercase font-bold text-on-surface-secondary">Instant</p>
                        </div>
                    </button>
                ))}
            </div>

            <div className="bg-surface p-4 rounded-lg shadow">
                <h3 className="font-bold text-on-surface mb-3">Recent Activity</h3>
                <div className="space-y-3">
                    {user.transactions?.slice(0, 5).map(tx => (
                        <div key={tx.id} className="flex justify-between items-center text-sm border-b pb-2">
                            <div>
                                <p className="font-medium">{tx.description}</p>
                                <p className="text-[10px] text-on-surface-secondary">{tx.date}</p>
                            </div>
                            <span className={tx.type === 'earned' ? 'text-success font-bold' : 'text-error font-bold'}>
                                {tx.type === 'earned' ? '+' : ''}{tx.coins}
                            </span>
                        </div>
                    ))}
                </div>
            </div>

            {selectedTier && (
                <RedemptionModal
                    user={user}
                    tier={selectedTier}
                    onClose={() => setSelectedTier(null)}
                    onConfirm={handleRedemption}
                />
            )}
        </div>
    );
};

export default WalletScreen;
