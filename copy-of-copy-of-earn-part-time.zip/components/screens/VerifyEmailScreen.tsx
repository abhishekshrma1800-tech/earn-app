import React, { useState } from 'react';
import Icon from '../icons';

interface VerifyEmailScreenProps {
    email: string;
    onContinue: () => void;
    onResend: () => void;
    onBackToLogin: () => void;
    title?: string;
    message?: string;
    continueButtonText?: string;
}

const VerifyEmailScreen: React.FC<VerifyEmailScreenProps> = ({ 
    email, 
    onContinue, 
    onResend, 
    onBackToLogin,
    title = "Verify Your Email",
    message = `We've sent a verification link to <span class="font-bold text-primary">{email}</span>. Please check your inbox and click the link to finish setting up your account.`,
    continueButtonText = "Continue (Simulated Verification)"
}) => {
    const [resent, setResent] = useState(false);

    const handleResendClick = () => {
        onResend();
        setResent(true);
        setTimeout(() => setResent(false), 3000); // Reset button state after 3 seconds
    };

    const formattedMessage = message.replace('{email}', email);

    return (
        <div className="min-h-screen bg-background flex flex-col justify-center items-center p-4">
            <div className="max-w-md w-full mx-auto bg-surface p-8 rounded-2xl shadow-xl text-center">
                <Icon name="Mail" className="w-20 h-20 text-primary mx-auto mb-6" />
                <h1 className="text-3xl font-bold text-on-surface">{title}</h1>
                <p 
                  className="text-on-surface-secondary mt-4"
                  dangerouslySetInnerHTML={{ __html: formattedMessage }}
                />
                <div className="mt-8 space-y-4">
                    <button
                        onClick={onContinue}
                        className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-on-primary bg-primary hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition"
                    >
                        {continueButtonText}
                    </button>
                    <button
                        onClick={handleResendClick}
                        disabled={resent}
                        className="w-full font-medium text-primary hover:text-primary-focus focus:outline-none disabled:text-on-surface-secondary disabled:cursor-not-allowed"
                    >
                        {resent ? "Verification Email Sent!" : "Didn't receive an email? Resend"}
                    </button>
                </div>

                <div className="mt-8 text-center">
                    <p className="text-sm text-on-surface-secondary">
                        Wrong email or already have an account?{' '}
                        <button onClick={onBackToLogin} className="font-medium text-primary hover:text-primary-focus focus:outline-none">
                            Back to Log In
                        </button>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default VerifyEmailScreen;