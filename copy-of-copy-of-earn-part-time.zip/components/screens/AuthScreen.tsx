import React, { useState } from 'react';
import Icon from '../icons';
import { User } from '../../types';
import { adminUser, regularUser } from '../../constants';
import ForgotPasswordScreen from './ForgotPasswordScreen';
import VerifyEmailScreen from './VerifyEmailScreen';
import AdminOtpScreen from './AdminOtpScreen';
import { generateOtp } from '../../services/geminiService';

interface AuthScreenProps {
  onAuthSuccess: (user: User, rememberMe: boolean) => void;
}

type AuthMode = 'LOGIN' | 'SIGNUP' | 'FORGOT_PASSWORD' | 'VERIFY_EMAIL' | 'ADMIN_OTP_VERIFY' | 'ADMIN_VERIFY_EMAIL';

const AuthScreen: React.FC<AuthScreenProps> = ({ onAuthSuccess }) => {
  const [mode, setMode] = useState<AuthMode>('SIGNUP');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [isAdminLogin, setIsAdminLogin] = useState(false);
  const [error, setError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Basic validation
    if (!email || !password || (mode === 'SIGNUP' && !confirmPassword)) {
      setError('All fields are required.');
      return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        setError('Please enter a valid email address.');
        return;
    }

    if (password.length < 8) {
      setError('Password must be at least 8 characters long.');
      return;
    }

    if (mode === 'SIGNUP' && password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    // --- Authentication Logic ---
    if (mode === 'LOGIN') {
      if (isAdminLogin) {
        setIsLoggingIn(true);
        // Simulate network delay for credential check
        setTimeout(async () => {
          if (email === "abhishekshrma1800@gmail.com" && password === "0507*Abhi") {
            try {
              const otp = await generateOtp();
              setGeneratedOtp(otp);
              setMode('ADMIN_VERIFY_EMAIL');
            } catch (err) {
               setError("Could not generate OTP. Please try again.");
            } finally {
               setIsLoggingIn(false);
            }
          } else {
            setError("Invalid admin credentials.");
            setIsLoggingIn(false);
          }
        }, 1000);
      } else {
        // Regular User Login (placeholder)
        onAuthSuccess(regularUser, rememberMe);
      }
    } else { // SIGNUP mode
      // After signup validation, move to email verification step
      console.log(`Verification email sent to ${email}`);
      setMode('VERIFY_EMAIL');
    }
  };

  const toggleMode = () => {
    setMode(prevMode => (prevMode === 'LOGIN' ? 'SIGNUP' : 'LOGIN'));
    setError('');
  };

  const handleResendAdminOtp = async (): Promise<boolean> => {
    try {
      const newOtp = await generateOtp();
      setGeneratedOtp(newOtp);
      return true;
    } catch (error) {
      console.error("Failed to resend OTP", error);
      setError("Failed to resend OTP. Please try again later.");
      return false;
    }
  };

  if (mode === 'FORGOT_PASSWORD') {
    return <ForgotPasswordScreen onBack={() => setMode('LOGIN')} successButtonText="Back to Log In" />;
  }

  if (mode === 'VERIFY_EMAIL') {
    return (
      <VerifyEmailScreen
        email={email}
        onContinue={() => onAuthSuccess(regularUser, true)} // Assume remember me for new signups
        onResend={() => alert(`Another verification email has been sent to ${email}.`)}
        onBackToLogin={() => setMode('LOGIN')}
      />
    );
  }

  if (mode === 'ADMIN_VERIFY_EMAIL') {
    return (
      <VerifyEmailScreen
        email={email}
        title="Admin Verification"
        message={`We've sent a 6-digit one-time password (OTP) to your admin email address at <span class="font-bold text-primary">{email}</span>. Please check your inbox to continue.`}
        continueButtonText="Enter OTP"
        onContinue={() => setMode('ADMIN_OTP_VERIFY')}
        onResend={() => alert(`Another OTP has been sent to ${email}.`)}
        onBackToLogin={() => setMode('LOGIN')}
      />
    );
  }

  if (mode === 'ADMIN_OTP_VERIFY') {
    return (
      <AdminOtpScreen
        email={email}
        onVerifySuccess={() => onAuthSuccess(adminUser, rememberMe)}
        onBackToLogin={() => setMode('LOGIN')}
        simulatedOtp={generatedOtp!}
        onResendOtp={handleResendAdminOtp}
      />
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center items-center p-4">
      <div className="max-w-md w-full mx-auto bg-surface p-8 rounded-2xl shadow-xl">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-primary">Earn Part-Time</h1>
          <p className="text-on-surface-secondary mt-2">
            {mode === 'LOGIN' ? 'Welcome back! Please log in.' : 'Create an account to get started.'}
          </p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-on-surface-secondary">Email Address</label>
            <div className="mt-1">
              <input id="email" name="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary" placeholder="you@example.com" />
            </div>
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-on-surface-secondary">Password</label>
            <div className="mt-1">
              <input id="password" name="password" type="password" autoComplete={mode === 'LOGIN' ? 'current-password' : 'new-password'} required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary" placeholder="••••••••" />
            </div>
          </div>

          {mode === 'SIGNUP' && (
             <div>
                <label htmlFor="confirm-password" className="block text-sm font-medium text-on-surface-secondary">Confirm Password</label>
                <div className="mt-1">
                  <input id="confirm-password" name="confirm-password" type="password" autoComplete="new-password" required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary" placeholder="••••••••" />
                </div>
            </div>
          )}

          {mode === 'LOGIN' && (
            <div className="flex items-center justify-between">
                <div className="flex items-center">
                    <input id="remember-me" name="remember-me" type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded" />
                    <label htmlFor="remember-me" className="ml-2 block text-sm text-on-surface-secondary">Remember me</label>
                </div>
                 <div className="text-sm">
                    <button type="button" onClick={() => setMode('FORGOT_PASSWORD')} className="font-medium text-primary hover:text-primary-focus focus:outline-none">Forgot password?</button>
                </div>
            </div>
          )}

          {mode === 'LOGIN' && (
            <div className="flex items-center">
                <input id="admin-login" name="admin-login" type="checkbox" checked={isAdminLogin} onChange={(e) => setIsAdminLogin(e.target.checked)} className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded" />
                <label htmlFor="admin-login" className="ml-2 block text-sm text-on-surface-secondary">Log in as Admin</label>
            </div>
          )}
          
          {error && <p className="text-sm text-error text-center">{error}</p>}

          <div>
            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-on-primary bg-primary hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition disabled:bg-gray-400"
            >
              {isLoggingIn && mode === 'LOGIN' && isAdminLogin && (
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="http://www.w3.org/2000/svg">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              )}
              {isLoggingIn && mode === 'LOGIN' && isAdminLogin ? 'Checking...' : (mode === 'LOGIN' ? 'Log In' : 'Sign Up')}
            </button>
          </div>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-on-surface-secondary">
            {mode === 'LOGIN' ? "Don't have an account? " : 'Already have an account? '}
            <button onClick={toggleMode} className="font-medium text-primary hover:text-primary-focus focus:outline-none">
              {mode === 'LOGIN' ? 'Sign Up' : 'Log In'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;
