import React, { useState } from 'react';
import Icon from '../icons';

interface HelpAndSupportScreenProps {}

interface FAQItemProps {
  question: string;
  answer: string;
}

const FAQItem: React.FC<FAQItemProps> = ({ question, answer }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="border-b">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex justify-between items-center text-left py-4 focus:outline-none"
            >
                <span className="font-semibold text-on-surface">{question}</span>
                <span className={`transform transition-transform duration-300 ${isOpen ? '-rotate-180' : 'rotate-0'}`}>
                   <Icon name="ChevronDown" className="w-5 h-5 text-on-surface-secondary" />
                </span>
            </button>
            <div
                className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96' : 'max-h-0'}`}
            >
                <p className="text-on-surface-secondary pb-4 px-2">{answer}</p>
            </div>
        </div>
    );
};


const HelpAndSupportScreen: React.FC<HelpAndSupportScreenProps> = () => {
  const faqs = [
    {
      q: 'How do I redeem my coins?',
      a: 'Navigate to the Wallet screen. From there, you can see your total coin balance and the available redemption options like PayPal, Google Pay, and Paytm. Select your preferred method and follow the on-screen instructions. You need a minimum of 1,000 coins to make a redemption.'
    },
    {
      q: 'Why was my task submission rejected?',
      a: 'Submissions are reviewed based on the task\'s verification method. Common reasons for rejection include incorrect or blurry screenshots, not following instructions completely, or failing a quiz. Please review the task description carefully before resubmitting.'
    },
    {
      q: 'How long does it take for my redemption to be processed?',
      a: 'Redemptions are typically processed within 3-5 business days. You will receive a confirmation email once the transaction is complete. If you haven\'t received your payment after 5 business days, please contact support.'
    },
    {
      q: 'Is my personal information safe?',
      a: 'Absolutely. We take your privacy seriously. We use industry-standard encryption to protect your data and never share your personal information with third parties without your consent. For more details, please read our Privacy Policy.'
    },
    {
        q: 'How does the referral program work?',
        a: 'You can find your unique referral code in your Profile. Share this code with friends. When a friend signs up using your code and completes their first task, you will both receive bonus coins as a reward. It\'s a win-win!'
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-on-surface">Help & Support</h2>
      </div>

      <div className="bg-surface p-6 rounded-lg shadow">
        <h3 className="font-bold text-lg text-on-surface mb-4">Contact Us</h3>
        <div className="space-y-3">
            <a href="mailto:support@earnparttime.app" className="w-full bg-gray-50 p-4 rounded-lg flex items-center space-x-4 text-left hover:bg-gray-100 transition-colors">
                <Icon name="Mail" className="w-8 h-8 text-primary" />
                <div>
                    <h4 className="font-bold text-on-surface">Email Support</h4>
                    <p className="text-sm text-primary">support@earnparttime.app</p>
                </div>
            </a>
            <button onClick={() => alert('Live Chat is currently unavailable. Please check back later.')} className="w-full bg-gray-50 p-4 rounded-lg flex items-center space-x-4 text-left hover:bg-gray-100 transition-colors">
                <Icon name="Social" className="w-8 h-8 text-primary" />
                 <div>
                    <h4 className="font-bold text-on-surface">Live Chat</h4>
                    <p className="text-sm text-on-surface-secondary">Available 24/7</p>
                </div>
            </button>
        </div>
      </div>
      
      <div className="bg-surface p-6 rounded-lg shadow">
        <h3 className="font-bold text-lg text-on-surface mb-2">Frequently Asked Questions</h3>
        <div className="divide-y">
            {faqs.map((faq, index) => (
                <FAQItem key={index} question={faq.q} answer={faq.a} />
            ))}
        </div>
      </div>

      <div className="bg-surface p-4 rounded-lg shadow">
         <div className="divide-y divide-gray-200">
             <button className="w-full text-left py-3 flex justify-between items-center hover:bg-gray-50 transition-colors">
                 <span className="text-on-surface">Terms of Service</span>
                 <Icon name="ChevronRight" className="w-5 h-5 text-on-surface-secondary" />
             </button>
             <button className="w-full text-left py-3 flex justify-between items-center hover:bg-gray-50 transition-colors">
                 <span className="text-on-surface">Privacy Policy</span>
                 <Icon name="ChevronRight" className="w-5 h-5 text-on-surface-secondary" />
             </button>
        </div>
        <p className="text-center text-xs text-on-surface-secondary mt-4">App Version: 1.0.0</p>
      </div>
    </div>
  );
};

export default HelpAndSupportScreen;
