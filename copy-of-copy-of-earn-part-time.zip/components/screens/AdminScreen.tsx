
import React from 'react';
import { Screen } from '../../types';
import Icon from '../icons';
import { db } from '../../services/storageService';

interface AdminScreenProps {
  onNavigate: (screen: Screen) => void;
}

const AdminOptionCard: React.FC<{ title: string; description: string; icon: string; onClick: () => void; }> = ({ title, description, icon, onClick }) => (
    <button onClick={onClick} className="w-full bg-surface p-4 rounded-lg shadow flex items-center space-x-4 text-left hover:bg-gray-50 hover:shadow-md transition-all">
        <div className="bg-primary bg-opacity-10 p-3 rounded-full">
            <Icon name={icon} className="w-8 h-8 text-primary" />
        </div>
        <div className="flex-grow">
            <h4 className="font-bold text-on-surface">{title}</h4>
            <p className="text-sm text-on-surface-secondary">{description}</p>
        </div>
        <Icon name="ChevronRight" className="w-6 h-6 text-on-surface-secondary" />
    </button>
);


const AdminScreen: React.FC<AdminScreenProps> = ({ onNavigate }) => {
  const logs = db.getLogs();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-on-surface">Admin Dashboard</h2>
        <p className="text-on-surface-secondary">System-wide controls & monitoring.</p>
      </div>

      <div className="space-y-4">
        <AdminOptionCard 
          title="Manage Tasks" 
          description="Moderate and generate tasks with Gemini."
          icon="Tasks"
          onClick={() => onNavigate(Screen.AdminTask)}
        />
        <AdminOptionCard 
          title="User Management" 
          description="Persistent database of user records."
          icon="Profile"
          onClick={() => onNavigate(Screen.AdminUserList)}
        />
        <AdminOptionCard 
          title="Ad Engine" 
          description="Manage multiple ad providers and revenue."
          icon="Coin"
          onClick={() => onNavigate(Screen.AdminAdRevenue)}
        />
        <AdminOptionCard 
          title="Financial Config" 
          description="Conversion rates and withdrawal thresholds."
          icon="Wallet"
          onClick={() => onNavigate(Screen.AdminFinancials)}
        />
      </div>

      <div className="bg-surface p-4 rounded-lg shadow">
        <div className="flex justify-between items-center mb-3">
            <h3 className="font-bold text-lg text-on-surface">System Logs</h3>
            <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-bold animate-pulse">LIVE</span>
        </div>
        <div className="bg-gray-900 rounded-md p-3 font-mono text-[10px] space-y-1 h-48 overflow-y-auto text-green-400">
            {logs.length > 0 ? logs.map((log, i) => (
                <div key={i}>
                    <span className="text-gray-500">[{new Date(log.timestamp).toLocaleTimeString()}]</span> {log.message}
                </div>
            )) : <p className="text-gray-500 italic text-center py-10">No logs available...</p>}
        </div>
      </div>
    </div>
  );
};

export default AdminScreen;
