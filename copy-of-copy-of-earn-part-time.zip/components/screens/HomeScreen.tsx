import React from 'react';
import { User, Category, Screen, Task, AdSettings } from '../../types';
import Icon from '../icons';
import AdSensePlaceholder from '../AdSensePlaceholder';

interface HomeScreenProps {
  user: User;
  categories: Category[];
  tasks: Task[];
  onCategorySelect: (category: Category) => void;
  onTaskSelect: (task: Task) => void;
  onNavigate: (screen: Screen) => void;
  adSettings: AdSettings;
}

const QuickWinCard: React.FC<{ task: Task; categoryIcon: string; onClick: () => void }> = ({ task, categoryIcon, onClick }) => (
  <button
    onClick={onClick}
    className="flex-shrink-0 w-64 bg-surface p-4 rounded-lg shadow-md mr-4 text-left hover:shadow-lg transition-shadow duration-200 flex flex-col justify-between"
  >
    <div>
      <div className="flex items-center mb-2">
        <div className="bg-secondary bg-opacity-10 p-2 rounded-full mr-3">
          <Icon name={categoryIcon} className="w-6 h-6 text-secondary" />
        </div>
        <h4 className="font-bold text-on-surface truncate flex-1">{task.title}</h4>
      </div>
      <p className="text-sm text-on-surface-secondary line-clamp-2">{task.description}</p>
    </div>
    <div className="flex items-center justify-end space-x-1 text-primary font-bold text-lg mt-3">
      <span>+{task.coins}</span>
      <Icon name="Coin" className="w-5 h-5 text-yellow-500" />
    </div>
  </button>
);

const CategoryCard: React.FC<{ category: Category; onClick: () => void }> = ({ category, onClick }) => (
  <button
    onClick={onClick}
    className="bg-surface p-3 rounded-xl shadow text-center flex flex-col items-center justify-center hover:shadow-lg hover:-translate-y-1 transition-all duration-200 aspect-square"
  >
    <div className="bg-primary bg-opacity-10 p-3 rounded-full mb-2">
       <Icon name={category.icon} className="w-10 h-10 text-primary" />
    </div>
    <p className="font-semibold text-on-surface text-xs leading-tight px-1">{category.name}</p>
    <p className="text-xs text-on-surface-secondary mt-0.5">{category.taskCount} Tasks</p>
  </button>
);

const HomeScreen: React.FC<HomeScreenProps> = ({ user, categories, tasks, onCategorySelect, onTaskSelect, onNavigate, adSettings }) => {
  const quickWinTasks = tasks
    .filter(task => !user.completedTaskIds.includes(task.id) && task.timeEstimateMinutes <= 5)
    .slice(0, 5);

  const getCategoryIcon = (categoryId: string) => {
    return categories.find(cat => cat.id === categoryId)?.icon || 'Tasks';
  };

  const bannerAdUnit = adSettings.adUnits.find(u => u.type === 'BANNER');

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-on-surface">Hello, {user.name.split(' ')[0]}!</h2>
        <p className="text-on-surface-secondary">Let's make today productive.</p>
      </div>

      <div className="bg-gradient-to-br from-primary to-secondary text-on-primary p-5 rounded-xl shadow-lg flex justify-around items-center">
        <div className="text-center">
          <p className="text-sm opacity-90">Your Coins</p>
          <div className="flex items-center justify-center space-x-2 mt-1">
            <Icon name="Coin" className="w-7 h-7 text-yellow-300" />
            <p className="text-3xl font-bold">{user.coins.toLocaleString()}</p>
          </div>
        </div>
        <div className="w-px h-12 bg-white opacity-30"></div>
        <div className="text-center">
          <p className="text-sm opacity-90">Tasks Done</p>
          <div className="flex items-center justify-center space-x-2 mt-1">
             <Icon name="CheckCircle" className="w-7 h-7" />
             <p className="text-3xl font-bold">{user.tasksCompleted}</p>
          </div>
        </div>
      </div>
      
      {quickWinTasks.length > 0 && (
        <div>
          <h3 className="text-xl font-bold text-on-surface mb-4">Quick Wins</h3>
          <div className="flex overflow-x-auto pb-4 -mb-4">
            {quickWinTasks.map(task => (
              <QuickWinCard 
                key={task.id} 
                task={task} 
                categoryIcon={getCategoryIcon(task.categoryId)}
                onClick={() => onTaskSelect(task)} 
              />
            ))}
            <div className="flex-shrink-0 w-1"></div>
          </div>
        </div>
      )}

      <div>
        <h3 className="text-xl font-bold text-on-surface mb-4">Explore Categories</h3>
        <div className="grid grid-cols-4 gap-3">
          {categories.map(cat => (
            <CategoryCard key={cat.id} category={cat} onClick={() => onCategorySelect(cat)} />
          ))}
        </div>
      </div>
      
      {adSettings.adsEnabled && bannerAdUnit?.enabled && adSettings.adSensePublisherId && (
        <div>
            <h3 className="text-sm font-bold text-on-surface-secondary mb-2 text-center uppercase tracking-wider">Sponsored</h3>
            <AdSensePlaceholder />
        </div>
      )}
    </div>
  );
};

export default HomeScreen;