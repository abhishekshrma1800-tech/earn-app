import React, { useState, useCallback, useEffect } from 'react';
import { Task, TaskType, AdSettings } from '../../types';
import Icon from '../icons';
import { generateCreativeContent } from '../../services/geminiService';
import SurveyModal from '../SurveyModal';
import AppVerificationModal from '../AppVerificationModal';
import RewardedAdModal from '../RewardedAdModal';

interface TaskDetailScreenProps {
  task: Task; // The initial task
  categoryTasks: Task[];
  onCompleteTask: (taskId: string, coins: number, wasCorrect: boolean) => void;
  completedTaskIds: string[];
  adSettings: AdSettings;
  onNavigateBack: () => void;
}

const getYouTubeEmbedUrl = (url: string | undefined): string | null => {
  if (!url) return null;
  let videoId = '';
  try {
    const urlObj = new URL(url);
    if (urlObj.hostname === 'youtu.be') {
      videoId = urlObj.pathname.slice(1);
    } else if (urlObj.hostname.includes('youtube.com')) {
      videoId = urlObj.searchParams.get('v') || '';
    }
    return videoId ? `https://www.youtube.com/embed/${videoId}` : null;
  } catch (error) {
    console.error("Invalid video URL:", url);
    return null;
  }
};

const TaskDetailScreen: React.FC<TaskDetailScreenProps> = ({ task: initialTask, categoryTasks, onCompleteTask, completedTaskIds, adSettings, onNavigateBack }) => {
  const [currentTask, setCurrentTask] = useState<Task>(initialTask);
  const [answerResult, setAnswerResult] = useState<'correct' | 'incorrect' | null>(null);

  const [creativePrompt, setCreativePrompt] = useState('');
  const [generatedContent, setGeneratedContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isCompleting, setIsCompleting] = useState(false);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  const [dataEntry, setDataEntry] = useState({ name: '', description: '' });
  const [isSurveyModalOpen, setIsSurveyModalOpen] = useState(false);
  const [isSurveyCompleted, setIsSurveyCompletedState] = useState(false);
  const [isRewardedAdModalOpen, setIsRewardedAdModalOpen] = useState(false);

  const [hasClickedInstall, setHasClickedInstall] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  
  const [captchaInput, setCaptchaInput] = useState('');
  const [selectedGridIndices, setSelectedGridIndices] = useState<number[]>([]);

  // States for Quiz Tasks
  const [quizStarted, setQuizStarted] = useState(false);
  const [quizCurrentIndex, setQuizCurrentIndex] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<('Yes' | 'No' | null)[]>([]);
  const [quizFinished, setQuizFinished] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  
  // Guard for when no task is active
  if (!currentTask) {
    return (
      <div className="text-center p-8">
        <p className="text-on-surface-secondary">Loading next task...</p>
      </div>
    );
  }

  const isCurrentTaskCompleted = completedTaskIds.includes(currentTask.id);
  const isCreativeTask = currentTask.type === TaskType.CREATIVE;
  const isDataEntryTask = currentTask.type === TaskType.DATA_ENTRY;
  const isSurveyTask = currentTask.type === TaskType.SURVEY;
  const isAppInstallTask = currentTask.type === TaskType.APP_INSTALLATION;
  const isVideoTask = currentTask.categoryId === 'c3' && !!currentTask.videoUrl;
  const isRewardedAdTask = currentTask.type === TaskType.REWARDED_AD;
  const isAutoCompletingVideoTask = isVideoTask && currentTask.verificationMethod === 'Automatic tracking';
  const isCaptchaTask = currentTask.type === TaskType.CAPTCHA;
  const isYesNoQuizTask = currentTask.type === TaskType.YES_NO_QUIZ;
  const isGradedQuizTask = currentTask.type === TaskType.GRADED_QUIZ;

  const hasProgressBar = (currentTask.timeEstimateMinutes > 1 && !isSurveyTask && !isCaptchaTask && !isYesNoQuizTask && !isGradedQuizTask) || isAutoCompletingVideoTask;
  
  const embedUrl = getYouTubeEmbedUrl(currentTask.videoUrl);

  const loadNextTask = () => {
    const updatedCompletedIds = [...completedTaskIds, currentTask.id];
  
    const remainingQuizzes = categoryTasks.filter(t => 
      (t.type === TaskType.YES_NO_QUIZ || t.type === TaskType.GRADED_QUIZ) &&
      !updatedCompletedIds.includes(t.id)
    );
  
    if (remainingQuizzes.length > 0) {
      setCurrentTask(remainingQuizzes[0]);
      // Reset all component states for the new task
      setCreativePrompt('');
      setGeneratedContent('');
      setIsLoading(false);
      setIsCompleting(false);
      setError('');
      setProgress(0);
      setDataEntry({ name: '', description: '' });
      setIsSurveyModalOpen(false);
      setIsSurveyCompletedState(false);
      setHasClickedInstall(false);
      setIsVerifying(false);
      setCaptchaInput('');
      setSelectedGridIndices([]);
      setQuizStarted(false);
      setQuizCurrentIndex(0);
      setQuizAnswers([]);
      setQuizFinished(false);
      setQuizScore(0);
      setAnswerResult(null);
    } else {
      alert("You've completed all quizzes in this category!");
      onNavigateBack();
    }
  };

  useEffect(() => {
    let timer: number | undefined;
    if (hasProgressBar && !isCurrentTaskCompleted) {
      const totalTimeInSeconds = currentTask.timeEstimateMinutes * 60;
      const increment = 100 / totalTimeInSeconds;
      
      timer = window.setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(timer);
            return 100;
          }
          return prev + increment;
        });
      }, 1000);
    }
    
    return () => {
      if (timer) {
        clearInterval(timer);
      }
    };
  }, [currentTask.id, currentTask.timeEstimateMinutes, hasProgressBar, isCurrentTaskCompleted]);

  useEffect(() => {
    if (isAutoCompletingVideoTask && progress >= 100 && !isCurrentTaskCompleted && !isCompleting) {
      setIsCompleting(true);
      setTimeout(() => {
        onCompleteTask(currentTask.id, currentTask.coins, true);
        onNavigateBack();
      }, 1000);
    }
  }, [progress, isAutoCompletingVideoTask, isCurrentTaskCompleted, isCompleting, onCompleteTask, currentTask.id, currentTask.coins, onNavigateBack]);


  const handleGenerateContent = useCallback(async () => {
    if (!creativePrompt.trim()) {
      setError('Please enter a prompt.');
      return;
    }
    setIsLoading(true);
    setError('');
    setGeneratedContent('');
    try {
      const content = await generateCreativeContent(creativePrompt);
      setGeneratedContent(content);
    } catch (err) {
      setError('Failed to generate content. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [creativePrompt]);

  const handleCaptchaSubmit = () => {
    if (isCurrentTaskCompleted) return;
    setIsCompleting(true);
    setError('');
    setTimeout(() => {
        let isCorrect = false;
        if (currentTask.captchaCorrectAnswer) {
            isCorrect = captchaInput.trim().toLowerCase() === currentTask.captchaCorrectAnswer.toLowerCase();
        } else if (currentTask.captchaGridCorrectIndices) {
            const sortedSelected = [...selectedGridIndices].sort((a,b) => a-b);
            const sortedCorrect = [...currentTask.captchaGridCorrectIndices].sort((a,b) => a-b);
            isCorrect = JSON.stringify(sortedSelected) === JSON.stringify(sortedCorrect);
        }

        if (isCorrect) {
            onCompleteTask(currentTask.id, currentTask.coins, true);
            setTimeout(onNavigateBack, 1500);
        } else {
            setError('Incorrect captcha. Please try again.');
            setIsCompleting(false);
            setCaptchaInput('');
            setSelectedGridIndices([]);
        }
    }, 1000);
  };
  
  const handleYesNoAnswer = (answer: 'Yes' | 'No') => {
    if (isCurrentTaskCompleted || isCompleting) return;
    setIsCompleting(true);
    setError('');

    const isCorrect = answer === currentTask.correctYesNoAnswer;
    setAnswerResult(isCorrect ? 'correct' : 'incorrect');
    if (!isCorrect) {
        setError('Incorrect answer. A 2 coin penalty has been applied.');
    }

    onCompleteTask(currentTask.id, currentTask.coins, isCorrect);

    setTimeout(loadNextTask, 1500);
  };

  const handleGradedQuizAnswer = (answer: 'Yes' | 'No') => {
    const newAnswers = [...quizAnswers, answer];
    setQuizAnswers(newAnswers);

    if (quizCurrentIndex < (currentTask.quizQuestions?.length || 0) - 1) {
      setQuizCurrentIndex(prev => prev + 1);
    } else {
      // Quiz finished, calculate score
      let score = 0;
      currentTask.quizQuestions?.forEach((q, index) => {
        if (newAnswers[index] === q.correctAnswer) {
          score++;
        }
      });
      setQuizScore(score);
      setQuizFinished(true);

      const isCorrect = score === currentTask.quizQuestions?.length;

      if (!isCorrect) {
          setError('A 2 coin penalty has been applied for failing the quiz.');
      }
      
      onCompleteTask(currentTask.id, currentTask.coins, isCorrect);
      setTimeout(loadNextTask, 2000); // Give user time to see score
    }
  };
  
  const resetQuiz = () => {
    setQuizStarted(true);
    setQuizCurrentIndex(0);
    setQuizAnswers([]);
    setQuizFinished(false);
    setQuizScore(0);
    setError('');
  };

  const handleCompleteTask = () => {
    if (isCurrentTaskCompleted || isCompleting) return;

    setIsCompleting(true);
    if (isDataEntryTask) {
      console.log('Submitting landmark data:', dataEntry);
    }
    onCompleteTask(currentTask.id, currentTask.coins, true);
    setTimeout(() => {
        onNavigateBack();
    }, 1500);
  };

  const handleVerification = () => {
    setIsVerifying(true);
  };

  const handleVerified = () => {
    onCompleteTask(currentTask.id, currentTask.coins, true);
    setIsVerifying(false);
    setTimeout(onNavigateBack, 1500);
  };
  
  const getButtonText = () => {
    if (isCurrentTaskCompleted) return 'Task Completed';
    if (isCompleting) return 'Verifying...';
    if (isCaptchaTask) return 'Verify Captcha';
    if (isAutoCompletingVideoTask) {
        if (progress < 100) return `Complete in ${Math.ceil((currentTask.timeEstimateMinutes * 60) * (1 - progress / 100))}s`;
        return 'Completing...';
    }
    if (isSurveyTask && !isSurveyCompleted) return 'Complete Survey to Continue';
    if (hasProgressBar && progress < 100) return `Complete in ${Math.ceil((currentTask.timeEstimateMinutes * 60) * (1 - progress / 100))}s`;
    return 'Mark as Complete';
  };
                           
  const isButtonDisabled = isCurrentTaskCompleted || isCompleting || 
                           (isCaptchaTask && !currentTask.captchaImageGrid && !captchaInput.trim()) ||
                           (isCaptchaTask && !!currentTask.captchaImageGrid && selectedGridIndices.length === 0) ||
                           isAutoCompletingVideoTask || 
                           (isCreativeTask && !generatedContent) || 
                           (isDataEntryTask && (!dataEntry.name.trim() || !dataEntry.description.trim())) ||
                           (isSurveyTask && !isSurveyCompleted) ||
                           (hasProgressBar && progress < 100);
                           
  const handleDataEntryChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setDataEntry(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };
  
  const toggleImageSelection = (index: number) => {
    setSelectedGridIndices(prev => 
        prev.includes(index) 
            ? prev.filter(i => i !== index)
            : [...prev, index]
    );
  };

  const mainButtonAction = isCaptchaTask ? handleCaptchaSubmit : handleCompleteTask;
  
  if (isRewardedAdTask) {
    return (
      <div className="space-y-6">
        <div className="bg-surface p-6 rounded-lg shadow text-center">
            <Icon name="Gift" className="w-16 h-16 text-primary mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-on-surface">{currentTask.title}</h2>
            <p className="text-on-surface-secondary my-4">{currentTask.description}</p>
            <div className="flex items-center justify-center space-x-2 text-primary font-bold text-3xl mb-6">
              <span>+{currentTask.coins}</span>
              <Icon name="Coin" className="w-8 h-8 text-yellow-500" />
            </div>
            <button
                onClick={() => setIsRewardedAdModalOpen(true)}
                disabled={isCurrentTaskCompleted}
                className="w-full bg-primary text-on-primary font-bold py-3 px-4 rounded-lg hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:bg-gray-400 disabled:cursor-not-allowed transition text-lg"
            >
                {isCurrentTaskCompleted ? 'Reward Claimed' : 'Watch Ad to Earn'}
            </button>
        </div>
        {isRewardedAdModalOpen && (
            <RewardedAdModal
                task={currentTask}
                onClose={() => setIsRewardedAdModalOpen(false)}
                onComplete={() => {
                    setIsRewardedAdModalOpen(false);
                    onCompleteTask(currentTask.id, currentTask.coins, true);
                    setTimeout(onNavigateBack, 1500);
                }}
            />
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-surface p-6 rounded-lg shadow">
        <div className="flex justify-between items-start">
            <div>
                <h2 className="text-2xl font-bold text-on-surface">{currentTask.title}</h2>
                <div className="flex items-center space-x-4 text-on-surface-secondary mt-2">
                    <div className="flex items-center space-x-1">
                        <Icon name="Clock" className="w-4 h-4" />
                        <span>{currentTask.timeEstimateMinutes} min estimate</span>
                    </div>
                </div>
            </div>
            <div className="flex items-center space-x-1 text-primary font-bold text-2xl">
              <span>{currentTask.coins}</span>
              <Icon name="Coin" className="w-7 h-7 text-yellow-500" />
            </div>
        </div>

        {hasProgressBar && !isCurrentTaskCompleted && (
          <div className="mt-4">
            <div className="flex justify-between mb-1">
              <span className="text-base font-medium text-primary">Task Progress</span>
              <span className="text-sm font-medium text-primary">{Math.floor(progress)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div className="bg-primary h-2.5 rounded-full transition-all duration-500" style={{width: `${progress}%`}}></div>
            </div>
          </div>
        )}

        <div className="border-t my-4"></div>

        <div>
          <h3 className="font-semibold text-on-surface mb-2">Description</h3>
          <p className="text-on-surface-secondary bg-gray-50 p-4 rounded-lg">{currentTask.description}</p>
        </div>
        
        {isVideoTask && embedUrl && (
          <div className="mt-4">
            <h3 className="font-semibold text-on-surface mb-2">Watch Video</h3>
            <div className="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
               <iframe 
                src={embedUrl}
                title={currentTask.title}
                frameBorder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowFullScreen
                className="w-full h-full"
                ></iframe>
            </div>
          </div>
        )}

        <div className="mt-4">
          <h3 className="font-semibold text-on-surface mb-2">Verification Method</h3>
          <p className="text-sm bg-blue-50 text-blue-800 p-4 rounded-lg">{currentTask.verificationMethod}</p>
        </div>
      </div>
      
      {isYesNoQuizTask && !isCurrentTaskCompleted && (
        <div className="bg-surface p-6 rounded-lg shadow space-y-4 text-center">
            <h3 className="font-semibold text-on-surface text-xl">Question:</h3>
            <div className="relative min-h-[6rem] flex items-center justify-center">
              <p className="text-2xl text-on-surface font-medium">{currentTask.yesNoQuestion}</p>
              {answerResult === 'correct' && (
                  <div className="absolute inset-0 bg-success/20 flex items-center justify-center rounded-lg">
                      <Icon name="CheckCircle" className="w-16 h-16 text-success" />
                  </div>
              )}
              {answerResult === 'incorrect' && (
                  <div className="absolute inset-0 bg-error/20 flex items-center justify-center rounded-lg">
                      <Icon name="X" className="w-16 h-16 text-error" />
                  </div>
              )}
            </div>
            {error && <p className="text-error text-sm font-semibold animate-pulse">{error}</p>}
            <div className="flex justify-around items-center pt-4">
                <button 
                    onClick={() => handleYesNoAnswer('Yes')}
                    disabled={isCompleting}
                    className="w-32 h-16 bg-success text-white font-bold text-2xl rounded-lg hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition disabled:bg-gray-400 flex items-center justify-center"
                >
                    Yes
                </button>
                <button 
                    onClick={() => handleYesNoAnswer('No')}
                    disabled={isCompleting}
                    className="w-32 h-16 bg-error text-white font-bold text-2xl rounded-lg hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition disabled:bg-gray-400 flex items-center justify-center"
                >
                    No
                </button>
            </div>
        </div>
      )}

      {isGradedQuizTask && !isCurrentTaskCompleted && (
        <div className="bg-surface p-6 rounded-lg shadow space-y-4 text-center">
            {!quizStarted ? (
                <>
                    <Icon name="Quiz" className="w-16 h-16 text-primary mx-auto" />
                    <h3 className="font-bold text-on-surface text-xl">You are about to start a quiz!</h3>
                    <p className="text-on-surface-secondary">You must answer all questions correctly to receive your reward. Incorrect attempts will result in a 2 coin penalty.</p>
                    <button onClick={() => resetQuiz()} className="w-full bg-primary text-on-primary font-bold py-3 px-4 rounded-lg hover:bg-primary-focus transition text-lg">
                        Start Quiz
                    </button>
                </>
            ) : !quizFinished ? (
                <div>
                    <div className="mb-4">
                        <p className="text-sm text-on-surface-secondary mb-1">Question {quizCurrentIndex + 1} of {currentTask.quizQuestions?.length}</p>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div className="bg-primary h-2.5 rounded-full transition-all duration-300" style={{width: `${((quizCurrentIndex + 1) / (currentTask.quizQuestions?.length || 1)) * 100}%`}}></div>
                        </div>
                    </div>
                    <p className="text-2xl text-on-surface font-medium min-h-[6rem] flex items-center justify-center">{currentTask.quizQuestions?.[quizCurrentIndex].questionText}</p>
                    <div className="flex justify-around items-center pt-4">
                        <button onClick={() => handleGradedQuizAnswer('Yes')} className="w-32 h-16 bg-success text-white font-bold text-2xl rounded-lg hover:bg-green-600 transition">Yes</button>
                        <button onClick={() => handleGradedQuizAnswer('No')} className="w-32 h-16 bg-error text-white font-bold text-2xl rounded-lg hover:bg-red-600 transition">No</button>
                    </div>
                </div>
            ) : (
                <div>
                    <h3 className="font-bold text-on-surface text-2xl mb-2">Quiz Complete!</h3>
                    <p className="text-lg text-on-surface-secondary">Your Score:</p>
                    <p className="text-5xl font-bold text-primary my-2">{quizScore} / {currentTask.quizQuestions?.length}</p>
                    {quizScore === currentTask.quizQuestions?.length ? (
                        <div className="text-center text-success font-semibold flex items-center justify-center space-x-2">
                             <Icon name="CheckCircle" className="w-6 h-6" />
                             <span>Perfect score! Loading next quiz...</span>
                        </div>
                    ) : (
                        <div>
                             <p className="text-error font-semibold mb-4">You need a perfect score to pass.</p>
                             {error && <p className="text-error text-sm font-semibold animate-pulse">{error}</p>}
                             <p className="text-on-surface-secondary text-sm mt-2">Loading next quiz...</p>
                        </div>
                    )}
                </div>
            )}
        </div>
      )}

      {isCaptchaTask && !isCurrentTaskCompleted && (
        <div className="bg-surface p-6 rounded-lg shadow space-y-4">
            <h3 className="font-semibold text-on-surface text-lg text-center">Complete the Captcha</h3>
            {error && <p className="text-error text-sm text-center font-semibold animate-pulse">{error}</p>}
            
            {currentTask.captchaImageUrl && (
                <div className="flex flex-col items-center space-y-4">
                    <div className="bg-gray-200 p-2 rounded-md">
                       <img src={currentTask.captchaImageUrl} alt="Captcha" className="border rounded-sm" />
                    </div>
                    <input 
                        type="text"
                        value={captchaInput}
                        onChange={(e) => setCaptchaInput(e.target.value)}
                        placeholder="Enter the text above"
                        className="w-full max-w-xs p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition text-center text-lg tracking-widest font-mono"
                        autoFocus
                        autoComplete="off"
                        autoCapitalize="off"
                        spellCheck="false"
                    />
                </div>
            )}

            {currentTask.captchaImageGrid && (
                <div>
                    <div className="grid grid-cols-3 gap-2 mx-auto max-w-xs sm:max-w-sm">
                        {currentTask.captchaImageGrid.map((imgUrl, index) => (
                            <button 
                                key={index} 
                                onClick={() => toggleImageSelection(index)} 
                                className={`relative rounded-md overflow-hidden border-4 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all duration-200 ${selectedGridIndices.includes(index) ? 'border-primary' : 'border-transparent'}`}
                                aria-label={`Select captcha image ${index + 1}`}
                                aria-pressed={selectedGridIndices.includes(index)}
                            >
                                <img src={imgUrl} alt={`Captcha image ${index + 1}`} className="w-full h-full object-cover aspect-square"/>
                                {selectedGridIndices.includes(index) && (
                                    <div className="absolute inset-0 bg-primary bg-opacity-60 flex items-center justify-center">
                                        <Icon name="CheckCircle" className="w-8 h-8 text-white" />
                                    </div>
                                )}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>
      )}

      {isAppInstallTask && !isCurrentTaskCompleted && (
        <div className="bg-surface p-6 rounded-lg shadow space-y-4 text-center">
            <h3 className="font-semibold text-on-surface text-lg">{!hasClickedInstall ? 'Step 1: Install the App' : 'Step 2: Verify Installation'}</h3>
            <p className="text-on-surface-secondary text-sm">
                {!hasClickedInstall 
                    ? 'Click the button below to go to the app store. After installing and setting it up, return here to complete the task.'
                    : 'Once you have installed and used the app for a few minutes, click the button below to verify the installation and claim your reward.'
                }
            </p>
            {!hasClickedInstall ? (
                 <a
                    href={currentTask.appInstallationUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setHasClickedInstall(true)}
                    className="inline-block w-full bg-secondary text-white font-bold py-3 px-4 rounded-lg hover:bg-secondary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary transition"
                >
                    Go to App Store
                </a>
            ) : (
                <button
                    onClick={handleVerification}
                    className="inline-block w-full bg-success text-white font-bold py-3 px-4 rounded-lg hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-success transition"
                >
                    Verify Installation
                </button>
            )}
        </div>
      )}

      {isSurveyTask && !isCurrentTaskCompleted && (
        <div className="bg-surface p-6 rounded-lg shadow space-y-4">
          <h3 className="font-semibold text-on-surface">Complete the Survey</h3>
          <p className="text-on-surface-secondary text-sm">You must complete a short survey to finish this task.</p>
          <button
            onClick={() => setIsSurveyModalOpen(true)}
            className="w-full bg-secondary text-white font-bold py-2 px-4 rounded-lg hover:bg-secondary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary transition"
          >
            Start Survey
          </button>
        </div>
      )}

      {isCreativeTask && !isCurrentTaskCompleted && (
        <div className="bg-surface p-6 rounded-lg shadow space-y-4">
          <h3 className="font-semibold text-on-surface">Creative Corner</h3>
          <p className="text-on-surface-secondary text-sm">Enter a prompt for the AI to write a short story.</p>
          <textarea
            value={creativePrompt}
            onChange={(e) => setCreativePrompt(e.target.value)}
            placeholder="e.g., A robot who discovers music for the first time"
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition"
            rows={3}
          />
          <button
            onClick={handleGenerateContent}
            disabled={isLoading}
            className="w-full bg-secondary text-white font-bold py-2 px-4 rounded-lg hover:bg-secondary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary disabled:bg-gray-400 transition"
          >
            {isLoading ? 'Generating...' : 'Generate Story'}
          </button>
          {error && <p className="text-error text-sm text-center">{error}</p>}
          {generatedContent && (
            <div className="border-t pt-4">
              <h4 className="font-semibold text-on-surface mb-2">Generated Content:</h4>
              <p className="text-on-surface-secondary bg-gray-50 p-3 rounded-md whitespace-pre-wrap">{generatedContent}</p>
            </div>
          )}
        </div>
      )}

      {isDataEntryTask && !isCurrentTaskCompleted && (
        <div className="bg-surface p-6 rounded-lg shadow space-y-4">
          <h3 className="font-semibold text-on-surface">Submit Landmark Information</h3>
          <p className="text-on-surface-secondary text-sm">Fill in the details below to complete the task.</p>
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-on-surface-secondary mb-1">
              Landmark Name
            </label>
            <input
              id="name"
              name="name"
              type="text"
              value={dataEntry.name}
              onChange={handleDataEntryChange}
              placeholder="e.g., Central Park Fountain"
              className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition"
            />
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-on-surface-secondary mb-1">
              Description
            </label>
            <textarea
              id="description"
              name="description"
              value={dataEntry.description}
              onChange={handleDataEntryChange}
              placeholder="e.g., A beautiful marble fountain located in the center of the park."
              className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition"
              rows={3}
            />
          </div>
        </div>
      )}

      {![isAppInstallTask, isYesNoQuizTask, isGradedQuizTask].some(Boolean) && (
        <div className="pt-2">
          <button
            onClick={mainButtonAction}
            disabled={isButtonDisabled}
            className="w-full bg-primary text-on-primary font-bold py-3 px-4 rounded-lg hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:bg-gray-400 disabled:cursor-not-allowed transition text-lg flex items-center justify-center"
          >
            {isCompleting && (
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            )}
            {getButtonText()}
          </button>
          {isAutoCompletingVideoTask && !isCurrentTaskCompleted && (
            <p className="text-center text-sm text-on-surface-secondary mt-2">
              This task will complete automatically when the progress bar reaches 100%.
            </p>
          )}
        </div>
      )}

      {isVerifying && (
        <AppVerificationModal
            isOpen={isVerifying}
            onVerified={handleVerified}
        />
      )}

      {isSurveyModalOpen && (
        <SurveyModal 
          questions={currentTask.questions || []}
          onClose={() => setIsSurveyModalOpen(false)}
          onComplete={() => {
            setIsSurveyCompletedState(true);
            setIsSurveyModalOpen(false);
          }}
          adSettings={adSettings}
        />
      )}
    </div>
  );
};

export default TaskDetailScreen;
