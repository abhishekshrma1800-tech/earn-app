
import React from 'react';
import { Category, Task } from '../../types';
import Icon from '../icons';

interface TasksScreenProps {
  category: Category;
  allTasks: Task[];
  onTaskSelect: (task: Task) => void;
  completedTaskIds: string[];
}

const TaskCard: React.FC<{ task: Task; onSelect: () => void; isCompleted: boolean }> = ({ task, onSelect, isCompleted }) => (
    <button
      onClick={onSelect}
      disabled={isCompleted}
      className={`w-full bg-surface p-4 rounded-lg shadow flex items-center justify-between space-x-4 text-left transition-all duration-200 ${isCompleted ? 'opacity-50 cursor-not-allowed' : 'hover:shadow-md hover:bg-gray-50'}`}
    >
      <div className="flex-grow">
        <h4 className="font-bold text-on-surface">{task.title}</h4>
        <p className="text-sm text-on-surface-secondary mt-1 line-clamp-2">{task.description}</p>
        <div className="flex items-center space-x-4 text-xs text-on-surface-secondary mt-2">
            <div className="flex items-center space-x-1">
                <Icon name="Clock" className="w-4 h-4" />
                <span>{task.timeEstimateMinutes} min</span>
            </div>
            {isCompleted && (
                 <div className="flex items-center space-x-1 text-success font-semibold">
                    <Icon name="CheckCircle" className="w-4 h-4" />
                    <span>Completed</span>
                </div>
            )}
        </div>
      </div>
      <div className="flex flex-col items-end flex-shrink-0">
         <div className="flex items-center space-x-1 text-primary font-bold text-lg">
          <span>{task.coins}</span>
          <Icon name="Coin" className="w-5 h-5 text-yellow-500" />
        </div>
        <Icon name="ChevronRight" className="w-6 h-6 text-on-surface-secondary mt-2" />
      </div>
    </button>
  );

const TasksScreen: React.FC<TasksScreenProps> = ({ category, allTasks, onTaskSelect, completedTaskIds }) => {
  const tasksForCategory = allTasks.filter(task => task.categoryId === category.id);

  return (
    <div className="space-y-4">
       <div className="flex items-center space-x-3 mb-4">
         <div className="bg-secondary bg-opacity-10 p-3 rounded-full">
            <Icon name={category.icon} className="w-8 h-8 text-secondary" />
         </div>
         <div>
            <h2 className="text-2xl font-bold text-on-surface">{category.name}</h2>
            <p className="text-on-surface-secondary">{category.taskCount} tasks available</p>
         </div>
       </div>

      {tasksForCategory.length > 0 ? (
        tasksForCategory.map(task => (
          <TaskCard key={task.id} task={task} onSelect={() => onTaskSelect(task)} isCompleted={completedTaskIds.includes(task.id)} />
        ))
      ) : (
        <p className="text-center text-on-surface-secondary">No tasks available in this category right now. Check back later!</p>
      )}
    </div>
  );
};

export default TasksScreen;
