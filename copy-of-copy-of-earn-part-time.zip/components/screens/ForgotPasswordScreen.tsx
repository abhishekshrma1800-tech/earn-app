import React, { useState } from 'react';
import Icon from '../icons';

interface ForgotPasswordScreenProps {
  successButtonText?: string;
}

const ForgotPasswordScreen: React.FC<ForgotPasswordScreenProps> = ({ successButtonText = "Back to Security" }) => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        setError('Please enter a valid email address.');
        return;
    }

    // Simulate sending the reset link
    console.log(`Password reset link sent to: ${email}`);
    setIsSubmitted(true);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-on-surface">Reset Password</h2>
      </div>

      <div className="bg-surface p-6 rounded-lg shadow">
        {isSubmitted ? (
          <div className="text-center">
            <Icon name="Mail" className="w-16 h-16 text-success mx-auto mb-4" />
            <h3 className="font-bold text-lg text-on-surface">Check Your Email</h3>
            <p className="text-on-surface-secondary mt-2">
              We've sent a password reset link to <span className="font-semibold text-primary">{email}</span>. Please check your inbox and follow the instructions.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <p className="text-on-surface-secondary">
              Enter your registered email address below and we'll send you a link to reset your password.
            </p>
            <div>
              <label htmlFor="reset-email" className="block text-sm font-medium text-on-surface-secondary mb-1">Email Address</label>
              <input
                type="email"
                id="reset-email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition"
                placeholder="you@example.com"
                required
                autoFocus
              />
            </div>
            
            {error && <p className="text-sm text-error text-center">{error}</p>}

            <div className="pt-2">
              <button
                type="submit"
                className="w-full bg-primary text-on-primary font-bold py-3 px-4 rounded-lg hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition"
              >
                Send Reset Link
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default ForgotPasswordScreen;
