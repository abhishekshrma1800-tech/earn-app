import React, { useState, useEffect, useRef } from 'react';
import { User, Task, Category, Screen } from '../../types';
import Icon from '../icons';
import { placeholderAvatars } from '../../constants';

interface ProfileScreenProps {
  user: User;
  onLogout: () => void;
  onUpdateUser: (updatedFields: Partial<User>) => void;
  allTasks: Task[];
  categories: Category[];
  onNavigate: (screen: Screen) => void;
}

// --- Helper Components (Defined outside ProfileScreen to prevent re-rendering issues) ---

const InfoRow: React.FC<{ label: string; value: string }> = ({ label, value }) => (
    <div className="flex justify-between items-center py-3">
        <span className="text-on-surface-secondary">{label}</span>
        <span className="font-semibold text-on-surface text-right">{value}</span>
    </div>
);

const EditableInfoRow: React.FC<{
    label: string;
    name: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    type?: string;
  }> = ({ label, name, value, onChange, type = 'text' }) => (
      <div className="flex justify-between items-center py-2">
          <label htmlFor={name} className="text-on-surface-secondary">{label}</label>
          <input
              id={name}
              name={name}
              type={type}
              value={value}
              onChange={onChange}
              className="w-2/3 md:w-1/2 text-right font-semibold text-on-surface bg-gray-100 rounded-md p-1 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
          />
      </div>
  );

const AvatarSelectionModal: React.FC<{ onSelect: (url: string) => void; onClose: () => void }> = ({ onSelect, onClose }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64String = reader.result as string;
                onSelect(base64String);
            };
            reader.readAsDataURL(file);
        } else if (file) {
            alert("Please select a valid image file (e.g., PNG, JPG, GIF).");
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4" aria-modal="true" role="dialog">
            <div className="bg-surface rounded-lg shadow-xl p-6 w-full max-w-sm">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold text-on-surface">Choose Your Avatar</h3>
                    <button onClick={onClose} className="text-on-surface-secondary hover:text-on-surface p-1 rounded-full">
                        <Icon name="X" className="w-6 h-6" />
                    </button>
                </div>
                
                <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                />

                <button
                    onClick={handleUploadClick}
                    className="w-full bg-primary text-on-primary font-bold py-3 px-4 rounded-lg hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition text-lg flex items-center justify-center space-x-2 mb-4"
                >
                    <Icon name="Upload" className="w-5 h-5" />
                    <span>Upload from phone</span>
                </button>

                <div className="relative my-4">
                    <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-gray-300"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                        <span className="bg-surface px-2 text-on-surface-secondary">OR SELECT ONE BELOW</span>
                    </div>
                </div>

                <div className="grid grid-cols-4 gap-4">
                    {placeholderAvatars.map((avatarUrl) => (
                        <button key={avatarUrl} onClick={() => onSelect(avatarUrl)} className="rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
                            <img src={avatarUrl} alt="Avatar option" className="w-16 h-16 rounded-full hover:opacity-80 transition-opacity" />
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};


const ProfileScreen: React.FC<ProfileScreenProps> = ({ user, onLogout, onUpdateUser, allTasks, categories, onNavigate }) => {
  const [isEditingLocation, setIsEditingLocation] = useState(false);
  const [location, setLocation] = useState(user.location || '');
  const [locationError, setLocationError] = useState('');
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [showAllHistory, setShowAllHistory] = useState(false);

  const [isEditingAccountInfo, setIsEditingAccountInfo] = useState(false);
  const [accountInfoData, setAccountInfoData] = useState({
    name: user.name,
    email: user.email,
    phoneNumber: user.phoneNumber || '',
  });
  const [accountInfoError, setAccountInfoError] = useState('');
  
  useEffect(() => {
    // Sync form state if the user prop changes, but NOT while editing.
    // This prevents the form from resetting during user input.
    if (!isEditingAccountInfo) {
      setAccountInfoData({
        name: user.name,
        email: user.email,
        phoneNumber: user.phoneNumber || '',
      });
      setLocation(user.location || '');
    }
  }, [user, isEditingAccountInfo]);

  const completedTasks = user.completedTaskIds
    .map(taskId => allTasks.find(task => task.id === taskId))
    .filter((task): task is Task => task !== undefined)
    .reverse(); // Show most recent first

  const getCategoryIcon = (categoryId: string) => {
    return categories.find(cat => cat.id === categoryId)?.icon || 'Tasks';
  };

  const handleLocationSave = () => {
    if (!location.trim()) {
      setLocationError('Location cannot be empty.');
      return;
    }
    setLocationError('');
    onUpdateUser({ location });
    setIsEditingLocation(false);
  };

  const handleLocationCancel = () => {
    setLocation(user.location || '');
    setLocationError('');
    setIsEditingLocation(false);
  };
  
  const handleAvatarSelect = (url: string) => {
    onUpdateUser({ profilePictureUrl: url });
    setIsAvatarModalOpen(false);
  };

  const handleAccountInfoSave = () => {
    if (!accountInfoData.name.trim()) {
        setAccountInfoError('Name cannot be empty.');
        return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(accountInfoData.email)) {
        setAccountInfoError('Please enter a valid email address.');
        return;
    }
    setAccountInfoError('');
    
    onUpdateUser({
        name: accountInfoData.name,
        email: accountInfoData.email,
        phoneNumber: accountInfoData.phoneNumber,
    });
    setIsEditingAccountInfo(false);
  };

  const handleAccountInfoCancel = () => {
    setAccountInfoData({
        name: user.name,
        email: user.email,
        phoneNumber: user.phoneNumber || '',
    });
    setAccountInfoError('');
    setIsEditingAccountInfo(false);
  };

  const handleAccountInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const { name, value } = e.target;
      setAccountInfoData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-6">
        <div className="flex flex-col items-center text-center">
            <div className="relative">
                <img 
                    src={user.profilePictureUrl} 
                    alt="Profile" 
                    className="w-24 h-24 rounded-full border-4 border-surface shadow-lg mb-2" 
                />
                <button
                    onClick={() => setIsAvatarModalOpen(true)}
                    className="absolute bottom-2 right-0 bg-primary text-white p-1.5 rounded-full shadow-md hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    aria-label="Change profile picture"
                >
                    <Icon name="Camera" className="w-4 h-4" />
                </button>
            </div>
            <h2 className="text-2xl font-bold text-on-surface mt-2">{user.name}</h2>
            <p className="text-on-surface-secondary">{user.email}</p>
            <div className="flex items-center justify-center text-on-surface-secondary mt-2 text-sm">
              {!isEditingLocation ? (
                <>
                  <Icon name="Location" className="w-4 h-4 mr-1.5" />
                  <span>{user.location || 'Location not set'}</span>
                  <button 
                    onClick={() => setIsEditingLocation(true)} 
                    className="ml-2 text-primary hover:text-primary-focus p-1 rounded-full focus:outline-none focus:ring-2 focus:ring-primary"
                    aria-label="Edit location"
                  >
                      <Icon name="Pencil" className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <div className="flex flex-col items-center space-y-1">
                  <div className="flex items-center space-x-2">
                    <input 
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className={`text-sm px-2 py-1 border rounded-md text-on-surface bg-background focus:ring-2 focus:ring-primary ${locationError ? 'border-error focus:ring-error' : 'focus:border-primary'}`}
                      autoFocus
                      onKeyDown={(e) => { if (e.key === 'Enter') handleLocationSave(); if (e.key === 'Escape') handleLocationCancel(); }}
                    />
                    <button 
                      onClick={handleLocationSave} 
                      className="text-success p-1 rounded-full hover:bg-green-100 focus:outline-none focus:ring-2 focus:ring-green-500"
                      aria-label="Save location"
                    >
                        <Icon name="CheckCircle" className="w-6 h-6" />
                    </button>
                    <button 
                      onClick={handleLocationCancel} 
                      className="text-error p-1 rounded-full hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-red-500"
                      aria-label="Cancel editing location"
                    >
                        <Icon name="X" className="w-6 h-6" />
                    </button>
                  </div>
                  {locationError && <p className="text-sm text-error">{locationError}</p>}
                </div>
              )}
            </div>
        </div>

        <div className="bg-surface p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg text-on-surface mb-2">Earning Statistics</h3>
            <div className="divide-y divide-gray-200">
                <InfoRow label="Total Coins Earned" value={user.coins.toLocaleString()} />
                <InfoRow label="Tasks Completed" value={user.tasksCompleted.toString()} />
                <InfoRow label="Referral Code" value={user.referralCode} />
            </div>
        </div>
        
        <div className="bg-surface p-4 rounded-lg shadow">
            <div className="flex justify-between items-center mb-2">
                <h3 className="font-bold text-lg text-on-surface">Account Information</h3>
                {!isEditingAccountInfo && (
                    <button 
                        onClick={() => setIsEditingAccountInfo(true)}
                        className="text-primary hover:text-primary-focus p-1 rounded-full focus:outline-none focus:ring-2 focus:ring-primary"
                        aria-label="Edit account information"
                    >
                        <Icon name="Pencil" className="w-5 h-5" />
                    </button>
                )}
            </div>
            
            {isEditingAccountInfo ? (
                <div className="divide-y divide-gray-200">
                    <EditableInfoRow label="Full Name" name="name" value={accountInfoData.name} onChange={handleAccountInfoChange} />
                    <EditableInfoRow label="Email Address" name="email" value={accountInfoData.email} onChange={handleAccountInfoChange} type="email" />
                    <EditableInfoRow label="Phone Number" name="phoneNumber" value={accountInfoData.phoneNumber} onChange={handleAccountInfoChange} type="tel" />
                    <InfoRow label="Join Date" value={user.joinDate || 'N/A'} />
                    {accountInfoError && <p className="text-sm text-error text-center pt-2">{accountInfoError}</p>}
                    <div className="flex justify-end space-x-2 pt-4">
                        <button onClick={handleAccountInfoCancel} className="px-4 py-2 bg-gray-200 text-on-surface-secondary rounded-lg hover:bg-gray-300 transition font-semibold">Cancel</button>
                        <button onClick={handleAccountInfoSave} className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-focus transition font-semibold">Save</button>
                    </div>
                </div>
            ) : (
                <div className="divide-y divide-gray-200">
                    <InfoRow label="Full Name" value={user.name} />
                    <InfoRow label="Email Address" value={user.email} />
                    <InfoRow label="Phone Number" value={user.phoneNumber || 'Not provided'} />
                    <InfoRow label="Join Date" value={user.joinDate || 'N/A'} />
                </div>
            )}
        </div>

        <div className="bg-surface p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg text-on-surface mb-2">Task Completion History</h3>
            {completedTasks.length > 0 ? (
                <div>
                    <div className="space-y-2">
                        {completedTasks.slice(0, showAllHistory ? completedTasks.length : 3).map(task => (
                            <div key={task.id} className="flex items-center justify-between py-2 border-b last:border-b-0">
                                <div className="flex items-center space-x-3 flex-1 min-w-0">
                                    <div className="bg-gray-100 p-2 rounded-full">
                                        <Icon name={getCategoryIcon(task.categoryId)} className="w-5 h-5 text-gray-600" />
                                    </div>
                                    <p className="font-semibold text-on-surface truncate">{task.title}</p>
                                </div>
                                <div className="flex items-center space-x-1 text-primary font-semibold flex-shrink-0 ml-2">
                                    <span>+{task.coins}</span>
                                    <Icon name="Coin" className="w-4 h-4 text-yellow-500" />
                                </div>
                            </div>
                        ))}
                    </div>
                    {completedTasks.length > 3 && (
                        <button
                            onClick={() => setShowAllHistory(!showAllHistory)}
                            className="w-full text-center text-primary font-semibold mt-4 py-2 hover:bg-gray-100 rounded-md"
                        >
                            {showAllHistory ? 'Show Less' : 'Show All'}
                        </button>
                    )}
                </div>
            ) : (
                <p className="text-on-surface-secondary text-center py-4">No tasks completed yet.</p>
            )}
        </div>

        <div className="bg-surface p-4 rounded-lg shadow">
             <h3 className="font-bold text-lg text-on-surface mb-2">Settings</h3>
             <div className="divide-y divide-gray-200">
                {user.isAdmin && (
                    <button onClick={() => onNavigate(Screen.Admin)} className="w-full text-left py-3 flex justify-between items-center hover:bg-gray-50 transition-colors">
                        <div className="flex items-center space-x-3">
                            <Icon name="Admin" className="w-5 h-5 text-primary" />
                            <span className="text-on-surface font-semibold">Admin Dashboard</span>
                        </div>
                        <Icon name="ChevronRight" className="w-5 h-5 text-on-surface-secondary" />
                    </button>
                )}
                 <button onClick={() => onNavigate(Screen.HelpAndSupport)} className="w-full text-left py-3 flex justify-between items-center hover:bg-gray-50 transition-colors">
                     <span className="text-on-surface">Help and Support</span>
                     <Icon name="ChevronRight" className="w-5 h-5 text-on-surface-secondary" />
                 </button>
                 <button onClick={() => onNavigate(Screen.Security)} className="w-full text-left py-3 flex justify-between items-center hover:bg-gray-50 transition-colors">
                     <span className="text-on-surface">Security</span>
                     <Icon name="ChevronRight" className="w-5 h-5 text-on-surface-secondary" />
                 </button>
            </div>
        </div>

        <div className="pt-4">
            <button 
                onClick={() => setShowLogoutConfirm(true)}
                className="w-full bg-error text-white font-bold py-2 px-4 rounded-lg hover:bg-red-600 transition">
                Log Out
            </button>
        </div>

        {showLogoutConfirm && (
            <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" aria-modal="true" role="dialog">
                <div className="bg-surface rounded-lg shadow-xl p-6 w-full max-w-sm">
                    <h3 className="text-lg font-bold text-on-surface">Confirm Logout</h3>
                    <p className="text-on-surface-secondary my-4">Are you sure you want to log out?</p>
                    <div className="flex justify-end space-x-4">
                        <button
                            onClick={() => setShowLogoutConfirm(false)}
                            className="px-4 py-2 bg-gray-200 text-on-surface-secondary rounded-lg hover:bg-gray-300 transition"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={onLogout}
                            className="px-4 py-2 bg-error text-white rounded-lg hover:bg-red-600 transition"
                        >
                            Log Out
                        </button>
                    </div>
                </div>
            </div>
        )}
        
        {isAvatarModalOpen && (
            <AvatarSelectionModal 
                onSelect={handleAvatarSelect} 
                onClose={() => setIsAvatarModalOpen(false)} 
            />
        )}
    </div>
  );
};

export default ProfileScreen;