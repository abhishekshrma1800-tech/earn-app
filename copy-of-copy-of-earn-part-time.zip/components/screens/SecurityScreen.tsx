import React, { useState } from 'react';
import Icon from '../icons';
import { Screen } from '../../types';

interface SecurityScreenProps {
  onNavigate: (screen: Screen) => void;
}

const SecurityScreen: React.FC<SecurityScreenProps> = ({ onNavigate }) => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handlePasswordUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!currentPassword || !newPassword || !confirmPassword) {
      setError('All fields are required.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('New passwords do not match.');
      return;
    }
    
    if (newPassword.length < 8) {
     setError('New password must be at least 8 characters long.');
     return;
    }

    // Placeholder logic for demonstration
    console.log('Updating password...');
    setSuccess('Password updated successfully!');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setTimeout(() => setSuccess(''), 3000); // Clear success message after 3 seconds
  };

  const handleForgotPassword = () => {
    onNavigate(Screen.ForgotPassword);
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-on-surface">Security Settings</h2>
      </div>

      <div className="bg-surface p-6 rounded-lg shadow space-y-4">
         <h3 className="font-bold text-lg text-on-surface">Change Password</h3>
         <form onSubmit={handlePasswordUpdate} className="space-y-4">
             <div>
                 <label htmlFor="currentPassword" className="block text-sm font-medium text-on-surface-secondary mb-1">Current Password</label>
                 <input 
                     type="password" 
                     id="currentPassword" 
                     value={currentPassword}
                     onChange={(e) => setCurrentPassword(e.target.value)}
                     className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" 
                     required 
                 />
             </div>
             <div>
                 <label htmlFor="newPassword" className="block text-sm font-medium text-on-surface-secondary mb-1">New Password</label>
                 <input 
                     type="password" 
                     id="newPassword"
                     value={newPassword}
                     onChange={(e) => setNewPassword(e.target.value)}
                     className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" 
                     placeholder="Minimum 8 characters"
                     required 
                 />
             </div>
             <div>
                 <label htmlFor="confirmPassword" className="block text-sm font-medium text-on-surface-secondary mb-1">Confirm New Password</label>
                 <input 
                     type="password" 
                     id="confirmPassword" 
                     value={confirmPassword}
                     onChange={(e) => setConfirmPassword(e.target.value)}
                     className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" 
                     required 
                 />
             </div>

             {error && <p className="text-sm text-error text-center">{error}</p>}
             {success && <p className="text-sm text-success text-center">{success}</p>}

             <div className="flex justify-between items-center pt-2">
                 <button type="button" onClick={handleForgotPassword} className="text-sm font-medium text-primary hover:text-primary-focus focus:outline-none">
                     Forgot Password?
                 </button>
                 <button 
                     type="submit" 
                     className="bg-primary text-on-primary font-bold py-2 px-6 rounded-lg hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition"
                 >
                     Save Changes
                 </button>
             </div>
         </form>
      </div>

      <div className="bg-surface p-6 rounded-lg shadow space-y-4">
         <h3 className="font-bold text-lg text-on-surface">Two-Factor Authentication (2FA)</h3>
         <div className="flex justify-between items-center">
             <p className="text-on-surface-secondary">Status: <span className="font-semibold text-error">Disabled</span></p>
             <button className="bg-gray-200 text-on-surface-secondary font-bold py-2 px-4 rounded-lg hover:bg-gray-300 transition">
                 Enable
             </button>
         </div>
      </div>

    </div>
  );
};

export default SecurityScreen;
