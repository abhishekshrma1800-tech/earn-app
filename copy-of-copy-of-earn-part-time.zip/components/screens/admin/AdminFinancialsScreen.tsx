
import React, { useState } from 'react';
import { FinancialSettings } from '../../../types';
import { db } from '../../../services/storageService';
import Icon from '../../icons';

const AdminFinancialsScreen: React.FC<{ settings: FinancialSettings; onUpdate: (s: FinancialSettings) => void }> = ({ settings, onUpdate }) => {
    const [rate, setRate] = useState(settings.conversionRate.toString());
    const [threshold, setThreshold] = useState(settings.minWithdrawalThreshold.toString());

    const handleSave = () => {
        onUpdate({
            ...settings,
            conversionRate: parseInt(rate),
            minWithdrawalThreshold: parseInt(threshold),
        });
        db.addLog(`Financial settings updated: 1 USD = ${rate} coins. Threshold = ${threshold} coins.`, 'info');
        alert('Settings Saved');
    };

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-bold text-on-surface">Financial Config</h2>
                <p className="text-on-surface-secondary">Set system-wide point values.</p>
            </div>

            <div className="bg-surface p-6 rounded-lg shadow space-y-4">
                <div className="flex items-center space-x-4 bg-blue-50 p-4 rounded-lg">
                    <Icon name="Coin" className="w-10 h-10 text-primary" />
                    <div>
                        <p className="text-sm font-bold text-blue-800">Point Conversion Rate</p>
                        <p className="text-xs text-blue-600">How many coins are worth $1 USD.</p>
                    </div>
                </div>
                
                <div className="space-y-2">
                    <label className="text-sm font-bold text-on-surface-secondary">Coins per $1 USD</label>
                    <input 
                        type="number"
                        value={rate}
                        onChange={(e) => setRate(e.target.value)}
                        className="w-full p-3 border rounded-lg text-black font-bold text-xl"
                    />
                </div>

                <div className="border-t pt-4 space-y-2">
                    <label className="text-sm font-bold text-on-surface-secondary">Min Withdrawal Threshold (Coins)</label>
                    <input 
                        type="number"
                        value={threshold}
                        onChange={(e) => setThreshold(e.target.value)}
                        className="w-full p-3 border rounded-lg text-black font-bold text-xl"
                    />
                </div>

                <button onClick={handleSave} className="w-full bg-primary text-on-primary font-bold py-3 rounded-lg shadow-md hover:bg-primary-focus transition">
                    Save Financial Config
                </button>
            </div>

            <div className="bg-surface p-4 rounded-lg shadow border border-yellow-200">
                <h3 className="font-bold text-yellow-800 flex items-center">
                    <Icon name="Lock" className="w-4 h-4 mr-2" />
                    Security Warning
                </h3>
                <p className="text-xs text-yellow-700 mt-1">
                    Changing the conversion rate will immediately affect all user balances. 
                    A higher rate means coins are worth less. Ensure users are notified of value changes.
                </p>
            </div>
        </div>
    );
};

export default AdminFinancialsScreen;
