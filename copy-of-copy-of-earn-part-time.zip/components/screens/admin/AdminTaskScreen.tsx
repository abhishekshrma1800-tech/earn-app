import React, { useState } from 'react';
import { Task, Screen, Category } from '../../../types';
import Icon from '../../icons';
import ConfirmationModal from '../../ConfirmationModal';

interface AdminTaskScreenProps {
  tasks: Task[];
  categories: Category[];
  onNavigate: (screen: Screen) => void;
  onEditTask: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
}

const AdminTaskScreen: React.FC<AdminTaskScreenProps> = ({ tasks, categories, onNavigate, onEditTask, onDeleteTask }) => {
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState<Task | null>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('all');

  const handleDeleteClick = (task: Task) => {
    setTaskToDelete(task);
    setIsConfirmModalOpen(true);
  };

  const handleConfirmDelete = () => {
    if (taskToDelete) {
      onDeleteTask(taskToDelete.id);
    }
    setIsConfirmModalOpen(false);
    setTaskToDelete(null);
  };

  const filteredTasks = selectedCategoryId === 'all'
    ? tasks
    : tasks.filter(task => task.categoryId === selectedCategoryId);
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-on-surface">Manage Tasks</h2>
        <button
          onClick={() => onNavigate(Screen.CreateTask)}
          className="bg-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-primary-focus flex items-center space-x-2 transition"
        >
          <Icon name="Plus" className="w-5 h-5" />
          <span>Add New Task</span>
        </button>
      </div>

      <div className="bg-surface p-4 rounded-lg shadow">
        <label htmlFor="category-filter" className="block text-sm font-medium text-on-surface-secondary mb-1">
          Filter by Category
        </label>
        <select
          id="category-filter"
          value={selectedCategoryId}
          onChange={(e) => setSelectedCategoryId(e.target.value)}
          className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition bg-white text-black"
        >
          <option value="all">All Categories</option>
          {categories.map(cat => (
            <option key={cat.id} value={cat.id}>{cat.name}</option>
          ))}
        </select>
      </div>
      
      <div className="bg-surface rounded-lg shadow">
        <h3 className="text-lg font-bold text-on-surface p-4 border-b">
          {selectedCategoryId === 'all' ? 'All Tasks' : categories.find(c => c.id === selectedCategoryId)?.name} ({filteredTasks.length})
        </h3>
        <ul className="divide-y divide-gray-200">
          {filteredTasks.length > 0 ? filteredTasks.map(task => (
            <li key={task.id} className="p-4 flex justify-between items-center hover:bg-gray-50">
              <div>
                <p className="font-semibold text-on-surface">{task.title}</p>
                <p className="text-sm text-on-surface-secondary">{task.coins} Coins | {task.timeEstimateMinutes} min</p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => onEditTask(task)}
                  className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"
                  aria-label={`Edit ${task.title}`}
                >
                  <Icon name="Pencil" className="w-5 h-5" />
                </button>
                <button
                  onClick={() => handleDeleteClick(task)}
                  className="p-2 text-error hover:bg-red-100 rounded-full"
                  aria-label={`Delete ${task.title}`}
                >
                  <Icon name="Trash" className="w-5 h-5" />
                </button>
              </div>
            </li>
          )) : (
            <p className="text-center text-on-surface-secondary p-6">No tasks found for this category.</p>
          )}
        </ul>
      </div>

      {isConfirmModalOpen && taskToDelete && (
        <ConfirmationModal
          isOpen={isConfirmModalOpen}
          onClose={() => {
            setIsConfirmModalOpen(false);
            setTaskToDelete(null);
          }}
          onConfirm={handleConfirmDelete}
          title="Confirm Deletion"
          message={`Are you sure you want to delete the task "${taskToDelete.title}"? This action cannot be undone.`}
          confirmButtonText="Delete"
          confirmButtonVariant="error"
        />
      )}
    </div>
  );
};

export default AdminTaskScreen;