
import React, { useState } from 'react';
import { AdSettings, AdUnit, AdProvider } from '../../../types';
import Icon from '../../icons';

const ProviderConfig: React.FC<{ 
    provider: AdProvider; 
    id: string | null; 
    onSave: (id: string) => void;
    onReset: () => void;
}> = ({ provider, id, onSave, onReset }) => {
    const [val, setVal] = useState(id || '');
    const isSaved = !!id;

    return (
        <div className="bg-gray-50 p-4 rounded-lg space-y-2 border">
            <h4 className="font-bold text-sm text-on-surface">{provider}</h4>
            {isSaved ? (
                <div className="flex justify-between items-center">
                    <span className="text-xs font-mono truncate max-w-[200px]">{id}</span>
                    <button onClick={onReset} className="text-xs text-error font-bold">Change</button>
                </div>
            ) : (
                <div className="flex space-x-2">
                    <input 
                        className="flex-grow p-1 text-xs border rounded bg-white text-black"
                        placeholder={`${provider} ID`}
                        value={val}
                        onChange={(e) => setVal(e.target.value)}
                    />
                    <button onClick={() => onSave(val)} className="bg-primary text-white text-xs px-3 py-1 rounded font-bold">Connect</button>
                </div>
            )}
        </div>
    );
};

const AdminAdRevenueScreen: React.FC<{ settings: AdSettings; onUpdateSettings: (s: Partial<AdSettings>) => void }> = ({ settings, onUpdateSettings }) => {
    const totalRevenue = settings.adUnits.reduce((acc, u) => acc + u.revenueGenerated, 0);

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-end">
                <div>
                    <h2 className="text-2xl font-bold text-on-surface">Ad Revenue Engine</h2>
                    <p className="text-on-surface-secondary">Multi-network monetization dashboard.</p>
                </div>
                <div className="text-right">
                    <p className="text-xs font-bold text-on-surface-secondary">Total Est. Revenue</p>
                    <p className="text-3xl font-bold text-success">${totalRevenue.toFixed(2)}</p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
                <ProviderConfig 
                    provider={AdProvider.ADSENSE} 
                    id={settings.adSensePublisherId}
                    onSave={(id) => onUpdateSettings({ adSensePublisherId: id })}
                    onReset={() => onUpdateSettings({ adSensePublisherId: null })}
                />
                <ProviderConfig 
                    provider={AdProvider.ADMOB} 
                    id={settings.adMobAppId}
                    onSave={(id) => onUpdateSettings({ adMobAppId: id })}
                    onReset={() => onUpdateSettings({ adMobAppId: null })}
                />
                <ProviderConfig 
                    provider={AdProvider.UNITY} 
                    id={settings.unityGameId}
                    onSave={(id) => onUpdateSettings({ unityGameId: id })}
                    onReset={() => onUpdateSettings({ unityGameId: null })}
                />
            </div>

            <div className="bg-surface p-4 rounded-lg shadow">
                <h3 className="font-bold mb-3">Active Ad Units</h3>
                <div className="space-y-3">
                    {settings.adUnits.map(unit => (
                        <div key={unit.id} className="flex justify-between items-center p-3 bg-gray-50 rounded border">
                            <div>
                                <p className="font-bold text-sm">{unit.name}</p>
                                <div className="flex items-center space-x-2 mt-1">
                                    <span className="text-[10px] bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full font-bold">{unit.provider}</span>
                                    <span className="text-[10px] bg-gray-200 text-gray-700 px-2 py-0.5 rounded-full font-bold">{unit.type}</span>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className="text-sm font-bold text-success">${unit.revenueGenerated.toFixed(2)}</p>
                                <button 
                                    onClick={() => {
                                        const newUnits = settings.adUnits.map(u => u.id === unit.id ? { ...u, enabled: !u.enabled } : u);
                                        onUpdateSettings({ adUnits: newUnits });
                                    }}
                                    className={`text-[10px] font-bold ${unit.enabled ? 'text-primary' : 'text-error'}`}
                                >
                                    {unit.enabled ? 'ACTIVE' : 'DISABLED'}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default AdminAdRevenueScreen;
