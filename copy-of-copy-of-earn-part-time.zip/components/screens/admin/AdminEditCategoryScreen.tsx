import React, { useState, useEffect } from 'react';
import { Category } from '../../../types';
import Icon, { icons } from '../../icons';

interface AdminEditCategoryScreenProps {
  category: Category | null;
  onSave: (category: Omit<Category, 'taskCount'>) => void;
}

const AdminEditCategoryScreen: React.FC<AdminEditCategoryScreenProps> = ({ category, onSave }) => {
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('Tasks');
  
  const availableIcons = Object.keys(icons);

  useEffect(() => {
    if (category) {
      setName(category.name);
      setIcon(category.icon);
    } else {
      setName('');
      setIcon(availableIcons[0] || 'Tasks');
    }
  }, [category]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Category name cannot be empty.');
      return;
    }
    onSave({
      id: category?.id || '',
      name,
      icon,
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-on-surface">{category ? 'Edit Category' : 'Create Category'}</h2>
      </div>

      <form onSubmit={handleSubmit} className="bg-surface p-6 rounded-lg shadow space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-on-surface-secondary mb-1">Category Name</label>
          <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} required className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" />
        </div>
        
        <div>
          <label htmlFor="icon" className="block text-sm font-medium text-on-surface-secondary mb-1">Icon</label>
          <div className="flex items-center space-x-4">
            <select id="icon" value={icon} onChange={e => setIcon(e.target.value)} required className="flex-grow w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition bg-white text-black">
              {availableIcons.map(iconName => (
                <option key={iconName} value={iconName}>{iconName}</option>
              ))}
            </select>
            <div className="p-3 bg-gray-100 rounded-lg">
                <Icon name={icon} className="w-8 h-8 text-primary" />
            </div>
          </div>
        </div>
        
        <div className="pt-2">
            <button type="submit" className="w-full bg-primary text-on-primary font-bold py-3 px-4 rounded-lg hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition text-lg">
                {category ? 'Save Changes' : 'Create Category'}
            </button>
        </div>
      </form>
    </div>
  );
};

export default AdminEditCategoryScreen;
