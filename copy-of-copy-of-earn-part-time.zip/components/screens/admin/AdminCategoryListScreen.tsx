import React, { useState } from 'react';
import { Category } from '../../../types';
import Icon from '../../icons';
import ConfirmationModal from '../../ConfirmationModal';

interface AdminCategoryListScreenProps {
  categories: Category[];
  onEditCategory: (category: Category) => void;
  onDeleteCategory: (categoryId: string) => void;
  onAddCategory: () => void;
}

const AdminCategoryListScreen: React.FC<AdminCategoryListScreenProps> = ({ categories, onEditCategory, onDeleteCategory, onAddCategory }) => {
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState<Category | null>(null);

  const handleDeleteClick = (category: Category) => {
    setCategoryToDelete(category);
    setIsConfirmModalOpen(true);
  };

  const handleConfirmDelete = () => {
    if (categoryToDelete) {
      onDeleteCategory(categoryToDelete.id);
    }
    setIsConfirmModalOpen(false);
    setCategoryToDelete(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-on-surface">Manage Categories</h2>
      </div>

      <div className="flex justify-end">
        <button
          onClick={onAddCategory}
          className="bg-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-primary-focus flex items-center space-x-2 transition"
        >
          <Icon name="Plus" className="w-5 h-5" />
          <span>Add New Category</span>
        </button>
      </div>
      
      <div className="bg-surface rounded-lg shadow">
        <h3 className="text-lg font-bold text-on-surface p-4 border-b">All Categories ({categories.length})</h3>
        <ul className="divide-y divide-gray-200">
          {categories.map(category => (
            <li key={category.id} className="p-4 flex justify-between items-center hover:bg-gray-50">
                <div className="flex items-center space-x-4">
                    <Icon name={category.icon} className="w-8 h-8 text-primary" />
                    <div>
                        <p className="font-semibold text-on-surface">{category.name}</p>
                        <p className="text-sm text-on-surface-secondary">{category.taskCount} tasks</p>
                    </div>
                </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => onEditCategory(category)}
                  className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"
                  aria-label={`Edit ${category.name}`}
                >
                  <Icon name="Pencil" className="w-5 h-5" />
                </button>
                <button
                  onClick={() => handleDeleteClick(category)}
                  className="p-2 text-error hover:bg-red-100 rounded-full"
                  aria-label={`Delete ${category.name}`}
                >
                  <Icon name="Trash" className="w-5 h-5" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>

       {isConfirmModalOpen && categoryToDelete && (
        <ConfirmationModal
          isOpen={isConfirmModalOpen}
          onClose={() => {
            setIsConfirmModalOpen(false);
            setCategoryToDelete(null);
          }}
          onConfirm={handleConfirmDelete}
          title="Confirm Deletion"
          message={`Are you sure you want to delete the category "${categoryToDelete.name}"? This might orphan some tasks.`}
          confirmButtonText="Delete"
          confirmButtonVariant="error"
        />
      )}
    </div>
  );
};

export default AdminCategoryListScreen;
