import React from 'react';
import { User, Screen } from '../../../types';
import Icon from '../../icons';

interface AdminUserListScreenProps {
  users: User[];
  onSelectUser: (user: User) => void;
}

const AdminUserListScreen: React.FC<AdminUserListScreenProps> = ({ users, onSelectUser }) => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-on-surface">Manage Users</h2>
      </div>

      <div className="bg-surface rounded-lg shadow">
        <h3 className="text-lg font-bold text-on-surface p-4 border-b">All Users ({users.length})</h3>
        <ul className="divide-y divide-gray-200">
          {users.map(user => (
            <li key={user.id}>
              <button 
                onClick={() => onSelectUser(user)}
                className="w-full p-4 flex justify-between items-center hover:bg-gray-50 text-left"
              >
                <div className="flex items-center space-x-4">
                  <img src={user.profilePictureUrl} alt={user.name} className="w-12 h-12 rounded-full" />
                  <div>
                    <p className="font-semibold text-on-surface">{user.name} {user.isAdmin && <span className="text-xs bg-primary text-white px-2 py-0.5 rounded-full ml-2">Admin</span>}</p>
                    <p className="text-sm text-on-surface-secondary">{user.email}</p>
                  </div>
                </div>
                <Icon name="ChevronRight" className="w-6 h-6 text-on-surface-secondary" />
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default AdminUserListScreen;
