import React, { useState, useEffect } from 'react';
import { User } from '../../../types';
import Icon from '../../icons';

interface AdminUserDetailsScreenProps {
  user: User;
  onUpdateUser: (updatedUser: User) => void;
}

const AdminUserDetailsScreen: React.FC<AdminUserDetailsScreenProps> = ({ user, onUpdateUser }) => {
  const [formData, setFormData] = useState<User>(user);

  useEffect(() => {
    setFormData(user);
  }, [user]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: checked }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      ...formData,
      coins: Number(formData.coins), // Ensure coins are a number
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-on-surface">Edit User: {user.name}</h2>
      </div>

      <form onSubmit={handleSubmit} className="bg-surface p-6 rounded-lg shadow space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-on-surface-secondary mb-1">Full Name</label>
          <input type="text" id="name" name="name" value={formData.name} onChange={handleInputChange} required className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" />
        </div>
        
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-on-surface-secondary mb-1">Email</label>
          <input type="email" id="email" name="email" value={formData.email} onChange={handleInputChange} required className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" />
        </div>

        <div>
          <label htmlFor="coins" className="block text-sm font-medium text-on-surface-secondary mb-1">Coins</label>
          <input type="number" id="coins" name="coins" value={formData.coins} onChange={handleInputChange} required min="0" className="w-full p-2 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition" />
        </div>

        <div className="flex items-center justify-between py-2">
          <label htmlFor="isAdmin" className="text-sm font-medium text-on-surface-secondary">Admin Status</label>
          <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" id="isAdmin" name="isAdmin" checked={!!formData.isAdmin} onChange={handleCheckboxChange} className="sr-only peer" />
            <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
            <span className="ml-3 text-sm font-medium text-on-surface">{formData.isAdmin ? 'Admin' : 'User'}</span>
          </label>
        </div>
        
        <div className="pt-2">
            <button type="submit" className="w-full bg-primary text-on-primary font-bold py-3 px-4 rounded-lg hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition text-lg">
                Save Changes
            </button>
        </div>
      </form>
    </div>
  );
};

export default AdminUserDetailsScreen;
