import React, { useState, useEffect } from 'react';

interface Ad {
  text: string;
  bgColor: string;
  textColor: string;
}

// Exporting for use in other components like the PreTaskAdModal
export const placeholderAds: Ad[] = [
  { text: 'Get 50% off on your next purchase at ShoeWorld!', bgColor: 'bg-blue-100', textColor: 'text-blue-800' },
  { text: 'Play the new hit game: "Coin Rush Adventures"!', bgColor: 'bg-green-100', textColor: 'text-green-800' },
  { text: 'Tired of cooking? Quick Eats delivers in minutes!', bgColor: 'bg-orange-100', textColor: 'text-orange-800' },
  { text: 'Upgrade your tech with GadgetZone. Deals this week!', bgColor: 'bg-indigo-100', textColor: 'text-indigo-800' },
  { text: 'Your dream vacation is just a click away. Book now!', bgColor: 'bg-pink-100', textColor: 'text-pink-800' },
];

interface AdSensePlaceholderProps {
  ad?: Ad; // Optional prop to display a specific ad
}

const AdSensePlaceholder: React.FC<AdSensePlaceholderProps> = ({ ad }) => {
  const [currentAd, setCurrentAd] = useState<Ad | null>(null);

  useEffect(() => {
    if (ad) {
      // If an ad is passed as a prop, use it. This allows parent control.
      setCurrentAd(ad);
    } else {
      // If no ad is passed, select a random one on mount.
      const randomIndex = Math.floor(Math.random() * placeholderAds.length);
      setCurrentAd(placeholderAds[randomIndex]);
    }
  }, [ad]); // Re-run effect if the `ad` prop changes.

  if (!currentAd) {
    // Render a default or loading state if no ad is available yet
    return (
        <div className="w-full h-24 bg-gray-200 border border-dashed border-gray-400 flex items-center justify-center rounded-lg mt-4">
            <p className="text-gray-500 text-sm font-medium">Loading Ad...</p>
        </div>
    );
  }

  return (
    <div className={`w-full h-24 border border-dashed border-gray-400 flex items-center justify-center rounded-lg mt-4 p-4 text-center transition-colors duration-500 ${currentAd.bgColor}`}>
      <p className={`text-sm font-semibold ${currentAd.textColor}`}>{currentAd.text}</p>
    </div>
  );
};

export default AdSensePlaceholder;