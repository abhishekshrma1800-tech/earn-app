import React from 'react';
import { Screen, User } from '../types';
import Icon from './icons';

interface BottomNavProps {
  activeScreen: Screen;
  onNavigate: (screen: Screen) => void;
  user: User;
}

interface NavItemProps {
  screen: Screen;
  label: string;
  icon: string;
  isActive: boolean;
  onClick: (screen: Screen) => void;
}

const NavItem: React.FC<NavItemProps> = ({ screen, label, icon, isActive, onClick }) => {
  const activeClasses = 'text-primary';
  const inactiveClasses = 'text-on-surface-secondary';
  return (
    <button
      onClick={() => onClick(screen)}
      className={`flex flex-col items-center justify-center w-full pt-2 pb-1 focus:outline-none transition-colors duration-200 ${isActive ? activeClasses : inactiveClasses}`}
    >
      <Icon name={icon} className="w-7 h-7 mb-1" />
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
};

const BottomNav: React.FC<BottomNavProps> = ({ activeScreen, onNavigate, user }) => {
  const navItems: { screen: Screen, label: string, icon: string }[] = [
    { screen: Screen.Home, label: 'Home', icon: 'Home' },
    { screen: Screen.Wallet, label: 'Wallet', icon: 'Wallet' },
    ...(user.isAdmin ? [{ screen: Screen.Admin, label: 'Admin', icon: 'Admin' }] : []),
    { screen: Screen.Profile, label: 'Profile', icon: 'Profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-surface border-t border-gray-200 flex justify-around shadow-top z-10">
      {navItems.map(item => (
        <NavItem
          key={item.screen}
          screen={item.screen}
          label={item.label}
          icon={item.icon}
          isActive={activeScreen === item.screen}
          onClick={onNavigate}
        />
      ))}
    </nav>
  );
};

export default BottomNav;