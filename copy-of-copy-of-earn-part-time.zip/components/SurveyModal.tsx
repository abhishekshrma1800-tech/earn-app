import React, { useState } from 'react';
import Icon from './icons';
import { AdSettings, AdUnitType } from '../types';
import AdSensePlaceholder from './AdSensePlaceholder';

interface SurveyModalProps {
  questions: string[];
  onClose: () => void;
  onComplete: () => void;
  adSettings: AdSettings;
}

const SurveyModal: React.FC<SurveyModalProps> = ({ questions, onClose, onComplete, adSettings }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<string[]>(() => Array(questions.length).fill(''));
  const totalQuestions = questions.length;
  const currentQuestion = questions[currentQuestionIndex];

  const surveyAdUnit = adSettings.adUnits.find(u => u.type === AdUnitType.INTERSTITIAL);
  
  const handleAnswerChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestionIndex] = e.target.value;
    setAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      // In a real app, you might want to pass the answers array back
      console.log("Final Survey Answers:", answers);
      onComplete();
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const isNextDisabled = !answers[currentQuestionIndex]?.trim();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
      <div className="bg-surface rounded-2xl shadow-2xl w-full max-w-md mx-auto flex flex-col max-h-[90vh]">
        <header className="p-4 border-b flex justify-between items-center">
          <h2 className="text-lg font-bold text-on-surface">Survey</h2>
          <button onClick={onClose} className="text-on-surface-secondary hover:text-on-surface">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </header>
        
        <div className="p-6 flex-grow overflow-y-auto">
          {/* Progress Bar */}
          <div className="mb-6">
            <p className="text-sm text-on-surface-secondary text-center mb-1">Question {currentQuestionIndex + 1} of {totalQuestions}</p>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300" 
                style={{ width: `${((currentQuestionIndex + 1) / totalQuestions) * 100}%` }}
              ></div>
            </div>
          </div>
          
          {/* Question, Answer Box */}
          <div>
            <label htmlFor="survey-answer" className="text-xl text-on-surface font-medium text-center mb-4 block">{currentQuestion}</label>
            <textarea
              id="survey-answer"
              value={answers[currentQuestionIndex]}
              onChange={handleAnswerChange}
              placeholder="Type your answer here..."
              className="w-full p-3 border rounded-md focus:ring-2 focus:ring-primary focus:border-primary transition bg-gray-50 mb-4 text-black"
              rows={4}
              autoFocus
            />
          </div>
          {adSettings.adsEnabled && surveyAdUnit?.enabled && adSettings.adSensePublisherId && (
            <div className="mt-4">
              <AdSensePlaceholder />
            </div>
          )}
        </div>

        <footer className="p-4 border-t flex justify-between items-center">
          <button
            onClick={handlePrev}
            disabled={currentQuestionIndex === 0}
            className="px-6 py-2 border rounded-lg font-semibold text-on-surface-secondary hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition"
          >
            Previous
          </button>
          <button
            onClick={handleNext}
            disabled={isNextDisabled}
            className="px-6 py-2 bg-primary text-on-primary font-bold rounded-lg hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {currentQuestionIndex === totalQuestions - 1 ? 'Finish' : 'Next'}
          </button>
        </footer>
      </div>
    </div>
  );
};

export default SurveyModal;