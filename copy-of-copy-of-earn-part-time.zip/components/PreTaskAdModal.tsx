import React, { useState, useEffect } from 'react';
import AdSensePlaceholder, { placeholderAds } from './AdSensePlaceholder';

interface PreTaskAdModalProps {
    onFinished: () => void;
}

const AD_DURATION = 5; // seconds
const AD_CYCLE_INTERVAL = 2000; // milliseconds

const PreTaskAdModal: React.FC<PreTaskAdModalProps> = ({ onFinished }) => {
    const [countdown, setCountdown] = useState(AD_DURATION);
    const [adIndex, setAdIndex] = useState(0);

    useEffect(() => {
        if (countdown <= 0) {
            onFinished();
            return;
        }

        const countdownTimer = setInterval(() => {
            setCountdown(prev => prev - 1);
        }, 1000);

        // Set up an interval to cycle through ads during the countdown
        const adCycleTimer = setInterval(() => {
            setAdIndex(prevIndex => (prevIndex + 1) % placeholderAds.length);
        }, AD_CYCLE_INTERVAL);


        return () => {
            clearInterval(countdownTimer);
            clearInterval(adCycleTimer);
        };
    }, [countdown, onFinished]);

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex flex-col items-center justify-center p-4 text-white">
            <div className="text-center mb-6">
                <h2 className="text-2xl font-bold">Advertisement</h2>
                <p className="text-gray-300">Your task will begin shortly...</p>
            </div>
            
            <div className="w-full max-w-sm">
                <AdSensePlaceholder ad={placeholderAds[adIndex]} />
            </div>

            <div className="mt-6">
                <p>Starting in <span className="font-bold text-lg">{countdown}</span></p>
            </div>
        </div>
    );
};

export default PreTaskAdModal;