/**
 * Requests permission from the user to show notifications.
 * It checks if the browser supports notifications and if permission has already been granted or denied.
 */
export const requestNotificationPermission = async (): Promise<void> => {
    if (!("Notification" in window)) {
        console.log("This browser does not support desktop notifications.");
        return;
    }

    // Don't ask again if permission is already granted or denied
    if (Notification.permission === 'granted' || Notification.permission === 'denied') {
        return;
    }

    try {
        const permission = await Notification.requestPermission();
        if (permission === "granted") {
            console.log("Notification permission granted.");
            // Show a welcome notification
            new Notification("Notifications Enabled!", {
                body: "You'll now be notified when new quizzes are available.",
            });
        }
    } catch (error) {
        console.error("Error requesting notification permission:", error);
    }
};

/**
 * Shows a push notification if permission has been granted.
 * @param categoryName The name of the quiz category that was updated.
 * @param count The number of new quizzes added.
 */
export const showNewQuizzesNotification = (categoryName: string, count: number): void => {
    if (Notification.permission !== "granted") {
        return;
    }

    // Fix: Add `vibrate` and `renotify` to the type definition using an intersection type
    // to resolve TypeScript errors for these non-standard but supported properties.
    const options: NotificationOptions & { vibrate?: number[], renotify?: boolean } = {
        body: `${count} new "${categoryName}" questions have been added. Tap to play!`,
        // Note: For icon and badge to work, you'd need to add image files to your project.
        // icon: '/logo192.png', 
        // badge: '/badge72.png',
        vibrate: [100, 50, 100], // Vibrate pattern
    };

    // Use a tag to prevent spamming notifications if they are generated quickly
    options.tag = 'new-quizzes';
    options.renotify = true;

    new Notification("New Quizzes Available!", options);
};