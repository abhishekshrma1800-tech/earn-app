
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const generateCreativeContent = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Write a very short, creative story (around 100 words) based on this prompt: "${prompt}"`,
      config: {
        temperature: 0.8,
        maxOutputTokens: 250,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error generating content:", error);
    throw new Error("Failed to generate content.");
  }
};

export const generateOtp = async (): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Generate a random 6-digit numeric one-time password (OTP). Respond with ONLY the 6 digits.",
      config: {
        temperature: 1.0,
        maxOutputTokens: 10,
      },
    });
    return response.text.trim().replace(/\D/g, '').slice(0, 6) || "123456";
  } catch (error) {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }
};

export const generateTasksForCategory = async (categoryName: string, categoryDescription: string): Promise<any[] | null> => {
  try {
    const prompt = `Generate 5 new earning tasks for a mobile app category called "${categoryName}". 
    Description of category: ${categoryDescription}.
    If it's a Quiz category, provide "yesNoQuestion" and "correctYesNoAnswer".
    If it's Social Media, provide a "title" like "Follow us on X" and a "description" of the action.
    The tasks should be distinct and helpful for users to earn coins.
    
    Response MUST be a JSON array of objects.
    Each object should have:
    - title: string
    - description: string
    - type: one of ["YES_NO_QUIZ", "GENERIC", "CREATIVE", "DATA_ENTRY"]
    - coins: number (between 5 and 20)
    - timeEstimateMinutes: number (between 0.5 and 5)
    - verificationMethod: string (e.g., "Automatic", "Manual Review")
    - yesNoQuestion?: string (if type is YES_NO_QUIZ)
    - correctYesNoAnswer?: "Yes" | "No" (if type is YES_NO_QUIZ)`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              type: { type: Type.STRING },
              coins: { type: Type.NUMBER },
              timeEstimateMinutes: { type: Type.NUMBER },
              verificationMethod: { type: Type.STRING },
              yesNoQuestion: { type: Type.STRING },
              correctYesNoAnswer: { type: Type.STRING },
            },
            required: ['title', 'description', 'type', 'coins', 'timeEstimateMinutes', 'verificationMethod'],
          },
        },
      },
    });

    const parsed = JSON.parse(response.text);
    return Array.isArray(parsed) ? parsed : null;
  } catch (error) {
    console.error(`Error generating for ${categoryName}:`, error);
    return null;
  }
};

// Legacy specialized generators kept for compatibility or specific logic
export const generateYesNoQuestion = async () => generateTasksForCategory('General Knowledge', 'General trivia questions');
export const generateMathYesNoQuestion = async () => generateTasksForCategory('Math', 'Simple arithmetic and logic');
export const generateGrammarYesNoQuestion = async () => generateTasksForCategory('Grammar', 'Correctness of sentences');
export const generateAnimalYesNoQuestion = async () => generateTasksForCategory('Animals', 'Facts about creatures');
