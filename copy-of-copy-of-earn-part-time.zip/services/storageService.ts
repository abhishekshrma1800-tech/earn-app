
import { AppDatabase, User, Task, Category, AdSettings, AdUnitType, FinancialSettings, AdProvider } from '../types';
import { adminUser, taskCategories as initialCategories, allTasks as initialTasks, allUsers as initialUsers } from '../constants';

const DB_KEY = 'earnparttime_db';

const initialAdSettings: AdSettings = {
  adsEnabled: true,
  adSensePublisherId: null,
  adMobAppId: null,
  unityGameId: null,
  adUnits: [
    { id: 'ad-banner-1', name: 'Home Banner', type: AdUnitType.BANNER, provider: AdProvider.ADSENSE, enabled: true, revenueGenerated: 12.50 },
    { id: 'ad-inter-1', name: 'Pre-Task Interstitial', type: AdUnitType.INTERSTITIAL, provider: AdProvider.ADMOB, enabled: true, revenueGenerated: 45.20 },
    { id: 'ad-reward-1', name: 'Rewarded Video Wall', type: AdUnitType.REWARDED, provider: AdProvider.UNITY, enabled: true, revenueGenerated: 120.80 },
  ],
};

const initialFinancialSettings: FinancialSettings = {
  conversionRate: 1000, // 1000 coins = 1 USD
  minWithdrawalThreshold: 4000, // 4000 coins min
  currency: 'USD',
};

const getDefaultDB = (): AppDatabase => ({
  users: initialUsers,
  tasks: initialTasks,
  categories: initialCategories,
  adSettings: initialAdSettings,
  financialSettings: initialFinancialSettings,
  logs: [{ timestamp: Date.now(), message: 'Database initialized with financial systems', type: 'info' }],
});

export const db = {
  get(): AppDatabase {
    try {
      const data = localStorage.getItem(DB_KEY);
      if (!data) {
        const defaultDB = getDefaultDB();
        this.save(defaultDB);
        return defaultDB;
      }
      return JSON.parse(data);
    } catch (e) {
      console.error('Database corruption, resetting...', e);
      return getDefaultDB();
    }
  },

  save(data: AppDatabase): void {
    localStorage.setItem(DB_KEY, JSON.stringify(data));
  },

  // User Actions
  getUsers(): User[] {
    return this.get().users;
  },

  saveUser(user: User): void {
    const data = this.get();
    const index = data.users.findIndex(u => u.id === user.id);
    if (index > -1) {
      data.users[index] = user;
    } else {
      data.users.push(user);
    }
    this.save(data);
  },

  // Task Actions
  getTasks(): Task[] {
    return this.get().tasks;
  },

  saveTasks(tasks: Task[]): void {
    const data = this.get();
    data.tasks = tasks;
    this.save(data);
  },

  // Financial Actions
  getFinancialSettings(): FinancialSettings {
    return this.get().financialSettings;
  },

  saveFinancialSettings(settings: FinancialSettings): void {
    const data = this.get();
    data.financialSettings = settings;
    this.save(data);
  },

  // Log Actions
  addLog(message: string, type: 'info' | 'success' | 'error' = 'info'): void {
    const data = this.get();
    data.logs.unshift({ timestamp: Date.now(), message, type });
    if (data.logs.length > 50) data.logs.pop();
    this.save(data);
  },

  getLogs() {
    return this.get().logs;
  },

  getCategories(): Category[] {
    const data = this.get();
    return data.categories.map(cat => ({
      ...cat,
      taskCount: data.tasks.filter(t => t.categoryId === cat.id).length
    }));
  }
};
