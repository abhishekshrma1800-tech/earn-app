
import React, { useState, useCallback, useEffect } from 'react';
import { Screen, Task, User, Category, Transaction, AdSettings, AdUnitType, TaskType, FinancialSettings } from './types';
import { db } from './services/storageService';
import Header from './components/Header';
import BottomNav from './components/BottomNav';
import HomeScreen from './components/screens/HomeScreen';
import TasksScreen from './components/screens/TasksScreen';
import TaskDetailScreen from './components/screens/TaskDetailScreen';
import WalletScreen from './components/screens/WalletScreen';
import ProfileScreen from './components/screens/ProfileScreen';
import AuthScreen from './components/screens/AuthScreen';
import CreateTaskScreen from './components/screens/CreateTaskScreen';
import AdminScreen from './components/screens/AdminScreen';
import EditTaskScreen from './components/screens/EditTaskScreen';
import SecurityScreen from './components/screens/SecurityScreen';
import HelpAndSupportScreen from './components/screens/HelpAndSupportScreen';
import ForgotPasswordScreen from './components/screens/ForgotPasswordScreen';

// Admin Screens
import AdminTaskScreen from './components/screens/admin/AdminTaskScreen';
import AdminUserListScreen from './components/screens/admin/AdminUserListScreen';
import AdminUserDetailsScreen from './components/screens/admin/AdminUserDetailsScreen';
import AdminCategoryListScreen from './components/screens/admin/AdminCategoryListScreen';
import AdminEditCategoryScreen from './components/screens/admin/AdminEditCategoryScreen';
import AdminAdRevenueScreen from './components/screens/admin/AdminAdRevenueScreen';
import AdminFinancialsScreen from './components/screens/admin/AdminFinancialsScreen';
import PreTaskAdModal from './components/PreTaskAdModal';
import { generateTasksForCategory } from './services/geminiService';
import { requestNotificationPermission, showNewQuizzesNotification } from './services/notificationService';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [user, setUser] = useState<User | null>(null);
  const [activeScreen, setActiveScreen] = useState<Screen>(Screen.Home);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  
  const [tasks, setTasks] = useState<Task[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [adSettings, setAdSettings] = useState<AdSettings>(db.get().adSettings);
  const [financialSettings, setFinancialSettings] = useState<FinancialSettings>(db.getFinancialSettings());

  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  const [userToEdit, setUserToEdit] = useState<User | null>(null);
  const [categoryToEdit, setCategoryToEdit] = useState<Category | null>(null);
  
  const [isPreTaskAdVisible, setIsPreTaskAdVisible] = useState(false);
  const [taskToShowAfterAd, setTaskToShowAfterAd] = useState<Task | null>(null);

  useEffect(() => {
    const initData = db.get();
    setTasks(initData.tasks);
    setCategories(db.getCategories());
    setAllUsers(initData.users);
    setFinancialSettings(initData.financialSettings);
    
    const storedUserId = localStorage.getItem('active_user_id');
    if (storedUserId) {
      const activeUser = initData.users.find(u => u.id === storedUserId);
      if (activeUser) {
        setUser(activeUser);
        setIsAuthenticated(true);
      }
    }
    requestNotificationPermission();
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;

    const runAutomation = async () => {
      setIsSyncing(true);
      const currentCategories = db.getCategories();
      const catToUpdate = currentCategories[Math.floor(Math.random() * currentCategories.length)];
      
      db.addLog(`Automation: Fetching tasks for ${catToUpdate.name}`, 'info');
      
      const newTasksRaw = await generateTasksForCategory(catToUpdate.name, "General earning tasks");
      
      if (newTasksRaw && newTasksRaw.length > 0) {
        const newTasks: Task[] = newTasksRaw.map(t => ({
          ...t,
          id: `auto-${catToUpdate.id}-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          categoryId: catToUpdate.id,
          type: t.type as TaskType,
        }));

        setTasks(prev => {
          const updated = [...newTasks, ...prev].slice(0, 500);
          db.saveTasks(updated);
          return updated;
        });

        db.addLog(`Added ${newTasks.length} tasks to ${catToUpdate.name}`, 'success');
        showNewQuizzesNotification(catToUpdate.name, newTasks.length);
        setCategories(db.getCategories());
      }
      setIsSyncing(false);
    };

    const intervalId = setInterval(runAutomation, 10 * 60 * 1000); // Every 10 mins
    runAutomation();

    return () => clearInterval(intervalId);
  }, [isAuthenticated]);

  const handleAuthSuccess = (loggedInUser: User, rememberMe: boolean) => {
    setUser(loggedInUser);
    setIsAuthenticated(true);
    setActiveScreen(Screen.Home);
    db.saveUser(loggedInUser);
    if (rememberMe) {
      localStorage.setItem('active_user_id', loggedInUser.id);
    }
  };
  
  const handleLogout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setActiveScreen(Screen.Home);
    localStorage.removeItem('active_user_id');
  };

  const navigate = (screen: Screen) => setActiveScreen(screen);

  const handleBack = () => {
    const backMap: Partial<Record<Screen, Screen>> = {
      [Screen.Tasks]: Screen.Home,
      [Screen.TaskDetail]: Screen.Tasks,
      [Screen.Security]: Screen.Profile,
      [Screen.HelpAndSupport]: Screen.Profile,
      [Screen.ForgotPassword]: Screen.Security,
      [Screen.AdminTask]: Screen.Admin,
      [Screen.AdminUserList]: Screen.Admin,
      [Screen.AdminCategoryList]: Screen.Admin,
      [Screen.AdminAdRevenue]: Screen.Admin,
      [Screen.AdminFinancials]: Screen.Admin,
      [Screen.CreateTask]: Screen.AdminTask,
      [Screen.EditTask]: Screen.AdminTask,
      [Screen.AdminUserDetails]: Screen.AdminUserList,
      [Screen.AdminEditCategory]: Screen.AdminCategoryList,
    };
    setActiveScreen(backMap[activeScreen] || Screen.Home);
  };

  const viewCategory = (category: Category) => {
    setSelectedCategory(category);
    navigate(Screen.Tasks);
  };

  const viewTask = (task: Task) => {
    const interstitialAdUnit = adSettings.adUnits.find(u => u.type === AdUnitType.INTERSTITIAL);
    if (adSettings.adsEnabled && interstitialAdUnit?.enabled && task.type !== TaskType.REWARDED_AD) {
        setTaskToShowAfterAd(task);
        setIsPreTaskAdVisible(true);
    } else {
        setSelectedTask(task);
        navigate(Screen.TaskDetail);
    }
  };

  const handleTaskCompletion = useCallback((taskId: string, coins: number, wasCorrect: boolean) => {
    if (!user) return;
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const newTransaction: Transaction = {
        id: `tx${Date.now()}`,
        date: new Date().toLocaleDateString(),
        description: wasCorrect ? task.title : `Incorrect: ${task.title}`,
        type: wasCorrect ? 'earned' : 'penalty',
        coins: wasCorrect ? coins : -2,
    };

    const updatedUser = {
      ...user,
      coins: user.coins + newTransaction.coins,
      tasksCompleted: user.tasksCompleted + 1,
      completedTaskIds: [...user.completedTaskIds, taskId],
      transactions: [newTransaction, ...(user.transactions || [])],
    };

    setUser(updatedUser);
    db.saveUser(updatedUser);
  }, [user, tasks]);

  const handleUpdateAdSettings = (newSettings: Partial<AdSettings>) => {
    const updated = { ...adSettings, ...newSettings };
    setAdSettings(updated);
    const fullDb = db.get();
    fullDb.adSettings = updated;
    db.save(fullDb);
  };

  const handleUpdateFinancialSettings = (newSettings: FinancialSettings) => {
    setFinancialSettings(newSettings);
    db.saveFinancialSettings(newSettings);
  };

  const renderScreen = () => {
    if (!user) return null;
    
    switch (activeScreen) {
      case Screen.Home: return <HomeScreen user={user} categories={categories} onCategorySelect={viewCategory} onNavigate={navigate} tasks={tasks} onTaskSelect={viewTask} adSettings={adSettings} />;
      case Screen.Tasks: return selectedCategory ? <TasksScreen category={selectedCategory} allTasks={tasks} onTaskSelect={viewTask} completedTaskIds={user.completedTaskIds} /> : null;
      case Screen.TaskDetail: return selectedTask ? <TaskDetailScreen task={selectedTask} categoryTasks={tasks.filter(t => t.categoryId === selectedTask.categoryId)} onCompleteTask={handleTaskCompletion} completedTaskIds={user.completedTaskIds} adSettings={adSettings} onNavigateBack={handleBack} /> : null;
      case Screen.Wallet: return <WalletScreen user={user} onUpdateUser={(u) => { const updated = {...user, ...u}; setUser(updated); db.saveUser(updated); }} />;
      case Screen.Profile: return <ProfileScreen user={user} onLogout={handleLogout} onUpdateUser={(u) => { const updated = {...user, ...u}; setUser(updated); db.saveUser(updated); }} allTasks={tasks} categories={categories} onNavigate={navigate} />;
      case Screen.Admin: return <AdminScreen onNavigate={navigate} />;
      case Screen.AdminTask: return <AdminTaskScreen tasks={tasks} categories={categories} onNavigate={navigate} onEditTask={setTaskToEdit} onDeleteTask={(id) => { const all = tasks.filter(t => t.id !== id); setTasks(all); db.saveTasks(all); }} />;
      case Screen.AdminAdRevenue: return <AdminAdRevenueScreen settings={adSettings} onUpdateSettings={handleUpdateAdSettings} />;
      case Screen.AdminFinancials: return <AdminFinancialsScreen settings={financialSettings} onUpdate={handleUpdateFinancialSettings} />;
      case Screen.AdminUserList: return <AdminUserListScreen users={allUsers} onSelectUser={(u) => { setUserToEdit(u); navigate(Screen.AdminUserDetails); }} />;
      default: return <HomeScreen user={user} categories={categories} onCategorySelect={viewCategory} onNavigate={navigate} tasks={tasks} onTaskSelect={viewTask} adSettings={adSettings} />;
    }
  };
  
  if (!isAuthenticated || !user) {
    return <AuthScreen onAuthSuccess={handleAuthSuccess} />;
  }

  return (
    <div className="max-w-md mx-auto min-h-screen bg-background font-sans flex flex-col shadow-2xl relative">
      <Header user={user} onProfileClick={() => navigate(Screen.Profile)} activeScreen={activeScreen} onBack={handleBack} />
      {isSyncing && (
        <div className="absolute top-16 left-0 right-0 z-50 flex justify-center">
          <div className="bg-primary/90 text-white text-[10px] px-3 py-1 rounded-full flex items-center space-x-2 animate-pulse shadow-lg">
            <svg className="animate-spin h-3 w-3 text-white" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
            <span>Auto-Generating Tasks...</span>
          </div>
        </div>
      )}
      <main className="flex-grow p-4 pb-24 overflow-y-auto">
        {renderScreen()}
      </main>
      {isPreTaskAdVisible && <PreTaskAdModal onFinished={() => { setIsPreTaskAdVisible(false); if (taskToShowAfterAd) { setSelectedTask(taskToShowAfterAd); navigate(Screen.TaskDetail); setTaskToShowAfterAd(null); } }} />}
      <BottomNav activeScreen={activeScreen} onNavigate={navigate} user={user} />
    </div>
  );
};

export default App;
